<head>
	
	<link rel="stylesheet" type="text/css" href="">


	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>

	<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.min.js" integrity="sha384-0pUGZvbkm6XF6gxjEnlmuGrJXVbNuzT9qBBavbLwCsOGabYfZo0T0to5eqruptLy" crossorigin="anonymous"></script>
</head>
<body>
	<center>
	<br>
	<h1>Student registration Form and status</h1>
	<a href="userclassreadboostrap.php" role="button" class="btn btn-outline-secondary">Display Classes</a>&nbsp;&nbsp;
	<a href="#" role="button" class="btn btn-outline-warning">new student insert</a><br><br>
</center>
<center>
<?php
error_reporting(1);

include('connection.php');
include('redirect.php');
extract($_POST);
	
	

@$classid = $_GET['classid'];

$availablestudent = $con->query("SELECT * FROM classlist WHERE classid= '$classid'");
$data = mysqli_fetch_array($availablestudent);





if($sub) {
	




/* CREATE YOUR MYSQL CONNECTION */
$user_list = $con->query("SELECT studentid FROM studentlist WHERE studentid='$sid'");
$user = mysqli_num_rows($user_list);



    if($user)
    {
        echo"<font color='red'>Already existed Studentid!.</font>";
    }elseif ($data['acceptingstudent']<= 0) {

    	 echo"<font color='red'>Already fulled Student numbers!.</font><br>";
    	
    }
  
    else
    {
        /* YOUR CODE */
    




  $rawdate = htmlentities($_POST['sdob']);
$date = date('Y-m-d', strtotime($rawdate));

$img=$_FILES['img']['name'];


@$classid = $_GET['classid'];

 $rawdatead = htmlentities($_POST['ad']);
$datead = date('Y-m-d', strtotime($rawdatead));



	 $query="insert into studentlist values ('','$sid','$sn','$date','$ss','$sm','$sc','$img','$datead','$cid','$cn','$no')";
    $con->query($query);

    $sql = "UPDATE classlist SET acceptingstudent = (acceptingstudent -1) WHERE classid = '$classid'";
    $con->query($sql);
    


     mkdir("image/$sid");
    move_uploaded_file($_FILES['img']['tmp_name'],"image/$sid/".$_FILES['img']['name']);

    echo "<font color='blue' align='center'>Congrates Student status insertion Complete!</font>";
    
     header("location:luckydraw1.php?studentid=$sid&studentname=$sn&classid=$classid&img=$img&classname=$cn");

	# code...
}

}

?>
</center>
<?php




?>
<div class="row">
  	<div class="col-sm-4"></div>


<div class="col-sm-4">
	<div class="container border" style="max-width: 700px;background-color:lightskyblue;">
<form method="post" enctype="multipart/form-data">

<?php
session_start();

$studentid = substr(md5(time()), 0, 10);

if(!isset($_SESSION['sid'])){
   $_SESSION['sid'] = $studentid;
}

if ($data['acceptingstudent'] == 0) {
	echo "<font color='red'>Already fulled Student numbers!.try another new class!</font><br>";

	echo "<font color='red'> Student id numbers cannot be generated!.try another new class!</font>";
	// code...
	// code...
}else{

	echo "<p style='color:green'>Available student...<input type='text' class='form-control' value=".$data['acceptingstudent']." readonly></p><br/>";
		echo "<p style='color:green'>Available student id number...<input type='text' class='form-control' name='sid' value=".$_SESSION['sid']." readonly></p>";

}
?><br><br>


<label for="Student Name">Student Name:</label><input type="text " class="form-control" name="sn" required/><br><br>
<label for="Student DOB">Student Date of Birth:</label>

<input type="date" 
        placeholder="yyyy-mm-dd" value=""
        min="1970-01-01" max="2030-12-31" class="form-control" id="date" placeholder="date" name="sdob" required/>  

        <br><br>
<label for="Status">Status:</label> <input type="text" class="form-control" name="ss" value="present" readonly /><br><br>
<label for="Mobile">Mobile:</label> <input type="number " class="form-control" name="sm" required/><br><br>
<label for="City">City:</label> <input type="text " class="form-control" name="sc" required/><br><br>
<label for="Choose Student Image">Choose Student Image:</label><input type="file" class="form-control-file" name="img" required/><br><br>
<label for="Enter Attendance Date">Enter Attendance Date:</label> <input type="date " class="form-control"  name="ad" value="<?php echo $_GET['startingdate']?>" readonly/><br><br>
<label for="Class Id">Class Id:</label> <input type="text " name="cid" class="form-control" value="<?php echo $_GET['classid']?>"  readonly /><br><br>
<label for="Class Name">Class Name:</label> <input type="text " name="cn" class="form-control" value="<?php echo $_GET['classname'] ?>" readonly /><br><br>
<label for="Course Completion status">Course Completion status:</label> <input type="text " name="no" class="form-control" value="new" readonly /><br><br>

 


<input type="submit" name="sub" value="INSERT DATA" class="btn btn-primary" />


</form>
</div>
</div>
<div class="col-sm-4"></div>
</div>

</body>