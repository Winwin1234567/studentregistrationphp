


<!DOCTYPE html>
<html>
<head>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>

	<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.min.js" integrity="sha384-0pUGZvbkm6XF6gxjEnlmuGrJXVbNuzT9qBBavbLwCsOGabYfZo0T0to5eqruptLy" crossorigin="anonymous"></script>
</head>
<body>



				
  <?php

        error_reporting(1);

extract($_GET);
include('connection.php');
include('redirect.php');

$items = array('10000','20000','30000','50000');
$index = array_rand($items,1);
$random_items = $items[$index];

if (isset($sub)) {

if(rand(1,1)==1){  


		@$n = $_GET['n2'];

		@$studentid = $_GET['studentid'];
		@$studentname = $_GET['studentname'];
		@$classid = $_GET['classid'];
		@$img = $_GET['img'];
		@$classname  = $_GET['classname'];
 

	$rawdate = htmlentities($_POST['rd']);
$rdate = date('Y-m-d', strtotime($rawdate));


		$q = $con->query("SELECT studentid FROM prize WHERE studentid='$sid'");
$r = mysqli_num_rows($q);

	if ($r) {
			echo"<font color='red'> Stop clicking again and again!Thank you!</font>";
		}else{	

		$query = "INSERT INTO prize VALUES('','$n','$sid','$sn','$dr','$rd','$img','$bs','$cn')";
		// code...
	if($con->query($query)===TRUE) {
		// code...
	
		
		// code...
	

 header("location:summarystudent.php?studentid=$sid&studentname=$sn&prize=$n&classid=$cid");


echo "<p><font color='green'>You gain ".$n." kyats.</font></p>";

		
		

}else{
	echo "<p style='color:red;'>Try again later!Please come again!</p>";
	



}
}
 
}
 	
}



?><hr/>

<center><h1>Lucky draw Discount!.</h1></center>

<div class="row">
  	<div class="col-sm-4">
  		
  	</div>


<div class="col-sm-4">
	<div class="container border" style="max-width: 700px;background-color:lightskyblue;">
		<center><img src="image/lucky-wheel.gif"></center>
	<form>


      


		<input type="text" name="n2" style="display: none;" value="<?php echo $random_items; ?>" readonly>

		 <label for="Student ID">Student ID:</label><input type="text " class="form-control" name="sid" value ="<?php echo $studentid;?>" readonly/><br><br>
       <label for="Student Name">Student Name:</label><input type="text " class="form-control" name="sn" value ="<?php echo $studentname;?>"  readonly/><br><br>
         <label for="Class ID">Class ID:</label><input type="text " class="form-control" name="cid" value ="<?php echo $classid;?>"  readonly/><br><br>
         <label for="Class Name">Class Name:</label><input type="text " class="form-control" name="cn" value ="<?php echo $classname;?>"  readonly/><br><br>
        
         <label for="Remark Summary">Remark Summary:</label> <textarea name="dr" class="form-control" readonly>new student</textarea><br><br>
 <label for="Remark date">Remark date:</label> <input type="date " class="form-control" name="rd" value="<?php echo date("Y.m.d");?>" readonly/><br><br>
 <label for="Student image name">Student image name:</label> <input type="text " class="form-control" name="img" value="<?php echo $img;?>" readonly/><br><br>
  <input type="text " name="bs" value ="0" style="display:none;" required/><br><br>
		<input type="submit" name="sub" value="lucky draw" class="btn btn-primary" style="margin-left: 150px;">

		
	</form>
	 </div>
	<?php
	
	 //echo "<a href='summarystudent.php?studentid=$sid&studentname=$sn&prize=$n&classid=$cid'>screenshot</a>";
		?>					


                     
                </div>
            


     	


<div class="col-sm-4">
</div>

</div>

</body>
</html>











</body>
</html>
