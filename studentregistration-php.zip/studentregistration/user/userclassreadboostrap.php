
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title></title>
   
</head>

<body>








<div class="container-xxl bg-white p-0">



            
                <div class="text-center mx-auto mb-5 wow fadeInUp" data-wow-delay="0.1s" style="max-width: 600px;">
                    <h1 class="mb-3">School Classes</h1>
                    <p>Attending class helps you do the following: Make connections between concepts. During class lectures and discussions, your brain will find connections to the assigned reading, previous class meetings, and your own life experiences. These connections serve as the foundation of learning!</p>
                </div>
                









<div class="container-xxl py-5 bg-secondary">

 <div class="d-grid gap-2 d-md-flex justify-content-md-end">
<button class="btn btn-outline-warning "><a href="index.php"><i class="bi bi-door-open"></i> < Back</a></button><br><br>
</div>


    <div class="container">

    
<div class="row g-4">
 

    <?php
    error_reporting(1);

    session_start();
    session_destroy();
    include('connection.php');
    include('redirect.php');
    include('booststyleconnect/styleconnection.php');
    $q = "SELECT * FROM classlist";
    $val = $con->query($q);
    while (list($classid,$classname,$timetable,$startingdate,$acceptingstudent,$classimg,$coursesummary) = mysqli_fetch_array($val)) {

        

                                 
                    
                   echo "<div class='col-lg-4 col-md-6 wow fadeInUp' data-wow-delay='0.1s'>";
                       echo "<div class='classes-item'>";
                           echo "<div class='bg-info rounded-circle w-75 mx-auto p-3'>";
                                
                              echo  "<center><img src='../admin/headofficer/class/classimage/$classname/$classimg' class=' rounded-circle' width='100px' height='75px' alt=''/></center>";
                               
                          echo  "</div>";
                           echo "<div class='bg-light rounded p-4 pt-5 mt-n5'>";
                             echo   "<a class='d-block text-center h3 mt-3 mb-4' href=''>".$classid." ".$classname."</a>";
                              echo  "<div class='d-flex align-items-center justify-content-between mb-4'>";
                                echo    "<div class='d-flex align-items-center'>";
                                     echo   "<img class='rounded-circle flex-shrink-0' src='../img/user.jpg' alt='' style='width: 45px; height: 45px;'>";
                                      echo  "<div class='ms-3'>";
                                        echo    "<h6 class='text-primary mb-1'>YKKO</h6>";
                                         echo   "<small>Sayar</small>";
                                       echo "</div>";
                                    echo "</div>";
                                    echo "<span class='bg-primary text-white rounded-pill py-2 px-3' href=''>".$startingdate."</span>";
                                echo "</div>";
                                echo "<div class='row g-1'>";
                                   echo "<div class='col-4'>";
                                       echo "<div class='border-top border-3 border-primary pt-2'>";
                                        echo    "<h6 class='text-primary mb-1'>course:</h6>";
                                         


     
    echo "<button class='btn btn-primary' type='button' data-bs-toggle='collapse' data-bs-target='#collapseExample1' aria-expanded='false' aria-controls='collapseExample'>
      Click me! 
    </button>";
  
  echo "<div class='collapse' id='collapseExample1'>";
    echo "<div class='card card-body'>";
   echo   "<small>".$coursesummary."</small>";
       
    echo"</div>";
 echo"</div>";

                                      echo  "</div>";
                                    echo "</div>";
                                   echo "<div class='col-4'>";
                                    echo    "<div class='border-top border-3 border-success pt-2'>";
                                        echo    "<h6 class='text-success mb-1'>Time:</h6>";
                                        echo    "<small>".$timetable."</small>";

                                       
                                        echo "</div>";
                                   echo "</div>";
                                    echo "<div class='col-4'>";
                                      echo  "<div class='border-top border-3 border-warning pt-2'>";
                                          echo  "<h6 class='text-warning mb-1'>Capacity:</h6>";
                                         echo   "<small>";

                                         if ($acceptingstudent>=2 && $acceptingstudent <= 10) {
                    // code...
                   echo "<font color='green'>".$acceptingstudent." ..Still available.</font>";
                }elseif ($acceptingstudent == 1) {
                    // code...
                   echo "<font color='orange'>".$acceptingstudent." ..only 1 person is availabe hurry up!!!</font>";
                }else{

                  echo  "<font color='red'>..full!please wait!</font>";
                }
                echo "</small>";

                
                                         echo "</div>";
                                    echo "</div>";

                                     echo"<div>";
                                        echo "<center><button class='btn btn-outline-primary'><a href='newstudentinsert.php?classid=$classid&classname=$classname&startingdate=$startingdate'><i class='bi bi-door-open'></i>New student register</a></button></center>";
                                         echo "</div>";

                                echo "</div>";
                            echo "</div>";
                        echo "</div>";
                    echo "</div>";
                

 }
        # code...
    

    ?>


 </div>

</div>








<?php include('footer.php') ?>

</div>
          
   </div>

</body>
</html>

