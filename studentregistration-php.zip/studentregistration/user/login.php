<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">

  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>

  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.min.js" integrity="sha384-0pUGZvbkm6XF6gxjEnlmuGrJXVbNuzT9qBBavbLwCsOGabYfZo0T0to5eqruptLy" crossorigin="anonymous"></script>





	<link rel="stylesheet" type="text/css" href="booststyleconnect/userlogincss.css">


	<title></title>
</head>


<?php

@$id = $_POST['id'];
//@$pass = $_POST['pass'];

if (isset($_POST['signin'])) {
	if ($id=="admin") {
         
		
     setcookie("cid",$id,time()+30*30);
     



		header("location:userclassreadboostrap.php");
		// code...
	}else{

		 

		echo " wrong id ",
		"try again later!";
	}
	// code...
}
?>
<body>



















  <div id="particles-js" class="snow"></div>

    <main>
       <div class="left-side"></div>
      
      <div class="right-side">
        <div class="d-grid gap-2 d-md-flex justify-content-md-end">
<button class="btn btn-outline-secondary "><a href="index.php"><i class="bi bi-door-open"></i> < Back</a></button><br><br>
</div>
        <form method="post">
        

        
	

        <label for="name">Name</label>
        <input type="text" placeholder="admin" name="id" value="admin" readonly />

       

        <button type="submit" name="signin" class="login-btn" value="Sign in">Sign in</button>
        
      </form>
      
      </div>
      
    </main>


<script src=
        "booststyleconnect/particles.js-master/particles.js">
    </script>
    <script src=
        "booststyleconnect/particles.js-master/demo/js/app.js">
    </script>

    <script type="text/javascript">


particlesJS("particles-js", {
  particles: {
    number: {
      value: 310,
      density: {
        enable: true,
        value_area: 800,
      },
    },
    color: {
      value: "#fff",
    },
    shape: {
      type: "circle",
      stroke: {
        width: 0,
        color: "#000000",
      },
      polygon: {
        nb_sides: 5,
      },
    },
    opacity: {
      value: 1,
      random: false,
      anim: {
        enable: false,
        speed: 1,
        opacity_min: 0.1,
        sync: false,
      },
    },
    size: {
      value: 3,
      random: true,
      anim: {
        enable: false,
      },
    },
    line_linked: {
      enable: false,
    },
    move: {
      enable: true,
      speed: 2,
      direction: "bottom",
      random: false,
      straight: false,
      out_mode: "out",
      bounce: false,
      attract: {
        enable: false,
        rotateX: 600,
        rotateY: 1200,
      },
    },
  },
  retina_detect: true,
});
</script>

</body>
</html>


