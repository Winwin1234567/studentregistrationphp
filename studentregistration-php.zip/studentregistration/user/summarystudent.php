<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>


<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>



<script type="text/javascript" src="https://cdn.datatables.net/2.0.8/js/dataTables.js"></script>

<script type="text/javascript" src="https://cdn.datatables.net/2.0.8/js/dataTables.bootstrap4.js"></script>
<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.2/css/bootstrap.css">
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/2.0.8/css/dataTables.bootstrap4.css">

</head>
<body class="bg-info">
<div class="row">
<div class="col-sm-4"></div>


<?php
error_reporting(1);

include('connection.php');
include('redirect.php');

extract($_GET);
$sid =  $_GET['studentid'];
$sn = $_GET['studentname'];
$p = $_GET['prize'];
$cid =$_GET['classid'];

$sql =$con->query("SELECT * FROM studentlist WHERE studentid='$sid'");
$data = mysqli_fetch_array($sql);

$sql1 =$con->query("SELECT * FROM classlist WHERE classid='$cid'");
$data1 = mysqli_fetch_array($sql1);

?>

<div class="col-sm-4 mt-3">
	<table  id="example" class="table table-hover table-sm table-bordered" align="center">
	

	<tr>
	<th>Your uploaded photo</th>
	<td><img src='./image/<?php echo $data['studentid'];?>/<?php echo $data['img'];?>' class='img-thumbnail' height='100' width='100' style="margin-left: 75px;"/></td>
</tr>
<tr>
	<th>Your StudentID is</th>
	<td><?php echo $data['studentid'];?></td>
</tr>
<tr>
	<th>Student name</th>
	<td><?php echo $data['studentname'];?></td>
</tr>
<tr>
	<th>class name</th>
	<td><?php echo $data['classnamename'];?></td>
</tr>
<tr>
	<th>timetable</th>
	<td><?php echo $data1['timetable'];?></td>
</tr>
<tr>
	<th>Joining date</th>
	<td><?php echo $data['attendance_date'];?></td>
</tr>
<tr>
	<th>Random discount amount</th>
	<td>Congratulation!You gain <?php echo $_GET['prize'];?>-MMk</td>

</tr>
<tr>
	<th>thank you message</th>
	<td>We appreciate our students!Thank you for joining with us!</td>
</tr>


</table>



</div>
<div class="col-sm-4"></div>
</div>
<?php 


@$id = $_POST['id'];
if (isset($_POST['sub'])) {
	if ($id=="logout") {
         
		
     setcookie("cid",$id,time()-30*30);
     



		header("location:index.php");
		// code...
	}else{

		 

		echo " wrong id ",
		"try again later!";
	}
}
?>
<form method="post" align="center">
	
	<input type="hidden" name="id" value="logout" /><br><br>
	<!--Enter password <input type="password" name="pass" />-->
	<font class="text-danger">Please Screenshot it before</font><input type="submit" name="sub" value="log out">.
</form>


</body>
</html>