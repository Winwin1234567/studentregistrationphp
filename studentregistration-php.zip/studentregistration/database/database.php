<?php
    $servername= "localhost";
    $username ="root";
    $password ="";
    


    //Creat connection
    $conn =new mysqli($servername,$username,$password);

    //Check connection
    if($conn->connect_error){
        die("Connection failed: ". $conn->connect_error);
    }
    echo "Connected successfully";

    $sql = "CREATE DATABASE IF NOT EXISTS studentdb";

    if($conn->query($sql) === TRUE){
        echo "Database created successfully";
    }else{
        echo "Database cannot create".$conn->error;
    }
    $conn->close();
?>

