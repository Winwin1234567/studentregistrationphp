-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Jul 04, 2024 at 09:33 AM
-- Server version: 8.2.0
-- PHP Version: 8.2.13

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `studentdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `classlist`
--

DROP TABLE IF EXISTS `classlist`;
CREATE TABLE IF NOT EXISTS `classlist` (
  `classid` int NOT NULL AUTO_INCREMENT,
  `classname` varchar(50) NOT NULL,
  `timetable` varchar(50) NOT NULL,
  `startingdate` date NOT NULL,
  `acceptingstudent` int NOT NULL,
  `classimg` varchar(20) NOT NULL,
  `coursesummary` varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`classid`)
) ENGINE=InnoDB AUTO_INCREMENT=77 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `classlist`
--

INSERT INTO `classlist` (`classid`, `classname`, `timetable`, `startingdate`, `acceptingstudent`, `classimg`, `coursesummary`) VALUES
(73, 'guitar', '9:30-11:00am fri', '2024-08-30', 10, 'guitar.png', 'Sayar smith is good musician and expert in playing it.'),
(71, 'module1ojt', '9:30-11:00am Sat Sun', '2024-06-29', 1, 'robot1-unscreen.gif', 'Sayar Core i7.Great at it. Good trainer.'),
(72, 'Yoga', '11:00-2:00pm Mon&Tue', '2024-08-12', 9, 'yoga-unscreen.gif', 'Teacher Adale great at stretching and expert it.'),
(70, 'htmlcssphp', '9:30-11:00am Tue-Thurs', '2024-06-04', 0, 'robot-unscreen.gif', 'Sayar YKKO good at it and good trainer.It is intensive course.'),
(74, 'English', '11:00-1:30pm Tue-Thurs', '2024-09-03', 9, 'call-to-action.jpg', 'Teacher Alex is proficiency in English.'),
(75, 'Pythondjango', '11:00-2:00pm sat sun', '2024-09-07', 9, 'pika.gif', 'Great sayar is teaching it now.'),
(76, 'React', '2:00-4:00pm wed-Fri', '2024-10-02', 10, 'hunter.gif', 'Sayar is great at teaching it.');

-- --------------------------------------------------------

--
-- Table structure for table `prize`
--

DROP TABLE IF EXISTS `prize`;
CREATE TABLE IF NOT EXISTS `prize` (
  `prizeid` int NOT NULL AUTO_INCREMENT,
  `prizename` varchar(50) NOT NULL,
  `studentid` varchar(50) NOT NULL,
  `studentname` varchar(20) NOT NULL,
  `remark` varchar(100) NOT NULL,
  `remarkdate` date NOT NULL,
  `img` varchar(20) NOT NULL,
  `bossreward` int NOT NULL,
  `classname` varchar(20) NOT NULL,
  PRIMARY KEY (`prizeid`)
) ENGINE=InnoDB AUTO_INCREMENT=104 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `prize`
--

INSERT INTO `prize` (`prizeid`, `prizename`, `studentid`, `studentname`, `remark`, `remarkdate`, `img`, `bossreward`, `classname`) VALUES
(95, '30000', 'c856648dd4', 'Mya Mya', 'A+ student Great in php.', '2024-07-04', 'appointment.jpg', 300000, 'htmlcssphp'),
(96, '20000', '55fe92625a', 'Aung Aung', 'A  student .Good job!', '2024-07-04', 'carousel-1.jpg', 100000, 'htmlcssphp'),
(97, '20000', 'ef86745151', 'Ko Ko', 'new student', '2024-07-03', 'carousel-2.jpg', 0, 'htmlcssphp'),
(98, '30000', 'ae229f5a59', 'kaung kaung', 'new student', '2024-07-03', 'classes-3.jpg', 0, 'htmlcssphp'),
(99, '50000', '540fa813ed', 'u ba', 'new student', '2024-07-03', 'testimonial-2.jpg', 0, 'htmlcssphp'),
(100, '50000', 'f710f7f82a', 'thiha', 'new student', '2024-07-03', 'classes-5.jpg', 0, 'htmlcssphp'),
(101, '20000', '9ef4c274cd', 'baby', 'new student', '2024-07-03', 'testimonial-1.jpg', 0, 'htmlcssphp'),
(102, '30000', '299cc846ef', 'Aye Aye', 'new student', '2024-07-04', 'classes-1.jpg', 0, 'Yoga'),
(94, '20000', '1712b86e40', 'kyaw kyar', 'new student', '2024-07-03', 'about-3.jpg', 0, 'htmlcssphp'),
(93, '10000', '1fd2ba08be', 'kyaw kyaw', 'new student', '2024-07-03', 'about-1.jpg', 0, 'htmlcssphp'),
(103, '20000', 'fd59265d5c', 'mg mg', 'new student', '2024-07-04', 'about-2.jpg', 0, 'English'),
(92, '20000', 'e0a25fb42a', 'mg mg', 'A++ student \r\n Excellent in htmlcss!', '2024-07-04', 'about-2.jpg', 700000, 'htmlcssphp');

-- --------------------------------------------------------

--
-- Table structure for table `studentlist`
--

DROP TABLE IF EXISTS `studentlist`;
CREATE TABLE IF NOT EXISTS `studentlist` (
  `id` int NOT NULL AUTO_INCREMENT,
  `studentid` varchar(20) COLLATE utf8mb4_general_ci NOT NULL,
  `studentname` varchar(20) COLLATE utf8mb4_general_ci NOT NULL,
  `studentdob` date NOT NULL,
  `status` varchar(20) COLLATE utf8mb4_general_ci NOT NULL,
  `mobile` varchar(20) COLLATE utf8mb4_general_ci NOT NULL,
  `city` varchar(20) COLLATE utf8mb4_general_ci NOT NULL,
  `img` varchar(20) COLLATE utf8mb4_general_ci NOT NULL,
  `attendance_date` date NOT NULL,
  `classidid` int NOT NULL,
  `classnamename` varchar(20) COLLATE utf8mb4_general_ci NOT NULL,
  `completestatus` varchar(20) COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=396 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `studentlist`
--

INSERT INTO `studentlist` (`id`, `studentid`, `studentname`, `studentdob`, `status`, `mobile`, `city`, `img`, `attendance_date`, `classidid`, `classnamename`, `completestatus`) VALUES
(316, 'e0a25fb42a', 'mg mg', '1990-10-03', 'present', '09123456789', 'yangon', 'about-2.jpg', '2024-06-04', 70, 'htmlcssphp', 'yes'),
(317, '1fd2ba08be', 'kyaw kyaw', '2005-06-04', 'present', '09123456780', 'yangon', 'about-1.jpg', '2024-06-04', 70, 'htmlcssphp', 'no'),
(318, '1712b86e40', 'kyaw kyar', '2000-06-05', 'present', '0987654321', 'yangon', 'about-3.jpg', '2024-06-04', 70, 'htmlcssphp', 'no'),
(319, 'c856648dd4', 'Mya Mya', '1993-10-05', 'present', '0912345678', 'mandalay', 'appointment.jpg', '2024-06-04', 70, 'htmlcssphp', 'no'),
(320, '55fe92625a', 'Aung Aung', '2000-10-25', 'present', '09123456780', 'yangon', 'carousel-1.jpg', '2024-06-04', 70, 'htmlcssphp', 'no'),
(321, 'ef86745151', 'Ko Ko', '2002-09-11', 'present', '09123456345', 'yangon', 'carousel-2.jpg', '2024-06-04', 70, 'htmlcssphp', 'no'),
(322, 'ae229f5a59', 'kaung kaung', '2004-07-08', 'present', '09123456345', 'yangon', 'classes-3.jpg', '2024-06-04', 70, 'htmlcssphp', 'no'),
(323, '540fa813ed', 'u ba', '1982-10-14', 'present', '0987654321', 'yangon', 'testimonial-2.jpg', '2024-06-04', 70, 'htmlcssphp', 'no'),
(324, 'f710f7f82a', 'thiha', '2002-06-05', 'present', '09123456789', 'yangon', 'classes-5.jpg', '2024-06-04', 70, 'htmlcssphp', 'no'),
(326, 'e0a25fb42a', 'mg mg', '1990-10-03', 'present', '09123456789', 'yangon', 'about-2.jpg', '2024-06-29', 71, 'module1ojt', 'no'),
(327, '1fd2ba08be', 'kyaw kyaw', '2005-06-04', 'present', '09123456780', 'yangon', 'about-1.jpg', '2024-06-29', 71, 'module1ojt', 'no'),
(328, '1712b86e40', 'kyaw kyar', '2000-06-05', 'present', '0987654321', 'yangon', 'about-3.jpg', '2024-06-29', 71, 'module1ojt', 'no'),
(329, 'c856648dd4', 'Mya Mya', '1993-10-05', 'present', '0912345678', 'mandalay', 'appointment.jpg', '2024-06-29', 71, 'module1ojt', 'no'),
(330, '55fe92625a', 'Aung Aung', '2000-10-25', 'present', '09123456780', 'yangon', 'carousel-1.jpg', '2024-06-29', 71, 'module1ojt', 'no'),
(331, 'ef86745151', 'Ko Ko', '2002-09-11', 'present', '09123456345', 'yangon', 'carousel-2.jpg', '2024-06-29', 71, 'module1ojt', 'no'),
(332, 'ae229f5a59', 'kaung kaung', '2004-07-08', 'present', '09123456345', 'yangon', 'classes-3.jpg', '2024-06-29', 71, 'module1ojt', 'no'),
(333, '9ef4c274cd', 'baby', '1983-06-08', 'present', '0987654321', 'yangon', 'testimonial-1.jpg', '2024-06-04', 70, 'htmlcssphp', 'no'),
(334, '540fa813ed', 'u ba', '1982-10-14', 'present', '0987654321', 'yangon', 'testimonial-2.jpg', '2024-06-29', 71, 'module1ojt', 'no'),
(335, 'f710f7f82a', 'thiha', '2002-06-05', 'present', '09123456789', 'yangon', 'classes-5.jpg', '2024-06-29', 71, 'module1ojt', 'no'),
(336, 'e0a25fb42a', 'mg mg', '1990-10-03', 'present', '09123456789', 'yangon', 'about-2.jpg', '2024-06-05', 70, 'htmlcssphp', 'yes'),
(337, 'e0a25fb42a', 'mg mg', '1990-10-03', 'present', '09123456789', 'yangon', 'about-2.jpg', '2024-06-06', 70, 'htmlcssphp', 'yes'),
(338, '1fd2ba08be', 'kyaw kyaw', '2005-06-04', 'present', '09123456780', 'yangon', 'about-1.jpg', '2024-06-05', 70, 'htmlcssphp', 'no'),
(339, '1fd2ba08be', 'kyaw kyaw', '2005-06-04', 'present', '09123456780', 'yangon', 'about-1.jpg', '2024-06-06', 70, 'htmlcssphp', 'no'),
(340, '1712b86e40', 'kyaw kyar', '2000-06-05', 'present', '0987654321', 'yangon', 'about-3.jpg', '2024-06-05', 70, 'htmlcssphp', 'no'),
(341, '1712b86e40', 'kyaw kyar', '2000-06-05', 'present', '0987654321', 'yangon', 'about-3.jpg', '2024-06-06', 70, 'htmlcssphp', 'no'),
(342, 'e0a25fb42a', 'mg mg', '1990-10-03', 'present', '09123456789', 'yangon', 'about-2.jpg', '2024-06-11', 70, 'htmlcssphp', 'yes'),
(343, 'e0a25fb42a', 'mg mg', '1990-10-03', 'present', '09123456789', 'yangon', 'about-2.jpg', '2024-06-12', 70, 'htmlcssphp', 'yes'),
(344, 'e0a25fb42a', 'mg mg', '1990-10-03', 'present', '09123456789', 'yangon', 'about-2.jpg', '2024-06-13', 70, 'htmlcssphp', 'yes'),
(345, '1fd2ba08be', 'kyaw kyaw', '2005-06-04', 'absent', '09123456780', 'yangon', 'about-1.jpg', '2024-06-11', 70, 'htmlcssphp', 'no'),
(346, '1fd2ba08be', 'kyaw kyaw', '2005-06-04', 'absent', '09123456780', 'yangon', 'about-1.jpg', '2024-06-12', 70, 'htmlcssphp', 'no'),
(347, '1fd2ba08be', 'kyaw kyaw', '2005-06-04', 'absent', '09123456780', 'yangon', 'about-1.jpg', '2024-06-13', 70, 'htmlcssphp', 'no'),
(348, '1712b86e40', 'kyaw kyar', '2000-06-05', 'absent', '0987654321', 'yangon', 'about-3.jpg', '2024-06-11', 70, 'htmlcssphp', 'no'),
(349, '1712b86e40', 'kyaw kyar', '2000-06-05', 'absent', '0987654321', 'yangon', 'about-3.jpg', '2024-06-12', 70, 'htmlcssphp', 'no'),
(350, '1712b86e40', 'kyaw kyar', '2000-06-05', 'absent', '0987654321', 'yangon', 'about-3.jpg', '2024-06-13', 70, 'htmlcssphp', 'no'),
(351, 'e0a25fb42a', 'mg mg', '1990-10-03', 'present', '09123456789', 'yangon', 'about-2.jpg', '2024-06-18', 70, 'htmlcssphp', 'yes'),
(352, 'e0a25fb42a', 'mg mg', '1990-10-03', 'present', '09123456789', 'yangon', 'about-2.jpg', '2024-06-19', 70, 'htmlcssphp', 'yes'),
(353, 'e0a25fb42a', 'mg mg', '1990-10-03', 'present', '09123456789', 'yangon', 'about-2.jpg', '2024-06-20', 70, 'htmlcssphp', 'yes'),
(354, 'e0a25fb42a', 'mg mg', '1990-10-03', 'present', '09123456789', 'yangon', 'about-2.jpg', '2024-06-25', 70, 'htmlcssphp', 'yes'),
(355, 'e0a25fb42a', 'mg mg', '1990-10-03', 'present', '09123456789', 'yangon', 'about-2.jpg', '2024-06-26', 70, 'htmlcssphp', 'yes'),
(356, 'e0a25fb42a', 'mg mg', '1990-10-03', 'present', '09123456789', 'yangon', 'about-2.jpg', '2024-06-27', 70, 'htmlcssphp', 'yes'),
(357, '1fd2ba08be', 'kyaw kyaw', '2005-06-04', 'absent', '09123456780', 'yangon', 'about-1.jpg', '2024-06-18', 70, 'htmlcssphp', 'no'),
(358, '1fd2ba08be', 'kyaw kyaw', '2005-06-04', 'absent', '09123456780', 'yangon', 'about-1.jpg', '2024-06-19', 70, 'htmlcssphp', 'no'),
(359, '1fd2ba08be', 'kyaw kyaw', '2005-06-04', 'present', '09123456780', 'yangon', 'about-1.jpg', '2024-06-20', 70, 'htmlcssphp', 'no'),
(360, '1fd2ba08be', 'kyaw kyaw', '2005-06-04', 'present', '09123456780', 'yangon', 'about-1.jpg', '2024-06-25', 70, 'htmlcssphp', 'no'),
(361, '1fd2ba08be', 'kyaw kyaw', '2005-06-04', 'present', '09123456780', 'yangon', 'about-1.jpg', '2024-06-26', 70, 'htmlcssphp', 'no'),
(362, '1fd2ba08be', 'kyaw kyaw', '2005-06-04', 'present', '09123456780', 'yangon', 'about-1.jpg', '2024-06-27', 70, 'htmlcssphp', 'no'),
(363, '1712b86e40', 'kyaw kyar', '2000-06-05', 'absent', '0987654321', 'yangon', 'about-3.jpg', '2024-06-18', 70, 'htmlcssphp', 'no'),
(364, '1712b86e40', 'kyaw kyar', '2000-06-05', 'absent', '0987654321', 'yangon', 'about-3.jpg', '2024-06-19', 70, 'htmlcssphp', 'no'),
(365, '1712b86e40', 'kyaw kyar', '2000-06-05', 'absent', '0987654321', 'yangon', 'about-3.jpg', '2024-06-20', 70, 'htmlcssphp', 'no'),
(366, '1712b86e40', 'kyaw kyar', '2000-06-05', 'absent', '0987654321', 'yangon', 'about-3.jpg', '2024-06-25', 70, 'htmlcssphp', 'no'),
(367, '1712b86e40', 'kyaw kyar', '2000-06-05', 'absent', '0987654321', 'yangon', 'about-3.jpg', '2024-06-25', 70, 'htmlcssphp', 'no'),
(368, '1712b86e40', 'kyaw kyar', '2000-06-05', 'absent', '0987654321', 'yangon', 'about-3.jpg', '2024-06-25', 70, 'htmlcssphp', 'no'),
(369, '1712b86e40', 'kyaw kyar', '2000-06-05', 'absent', '0987654321', 'yangon', 'about-3.jpg', '2024-06-26', 70, 'htmlcssphp', 'no'),
(370, '1712b86e40', 'kyaw kyar', '2000-06-05', 'present', '0987654321', 'yangon', 'about-3.jpg', '2024-06-27', 70, 'htmlcssphp', 'no'),
(371, 'c856648dd4', 'Mya Mya', '1993-10-05', 'present', '0912345678', 'mandalay', 'appointment.jpg', '2024-06-05', 70, 'htmlcssphp', 'no'),
(372, 'c856648dd4', 'Mya Mya', '1993-10-05', 'present', '0912345678', 'mandalay', 'appointment.jpg', '2024-06-06', 70, 'htmlcssphp', 'no'),
(373, 'c856648dd4', 'Mya Mya', '1993-10-05', 'present', '0912345678', 'mandalay', 'appointment.jpg', '2024-06-11', 70, 'htmlcssphp', 'no'),
(374, 'c856648dd4', 'Mya Mya', '1993-10-05', 'present', '0912345678', 'mandalay', 'appointment.jpg', '2024-06-12', 70, 'htmlcssphp', 'no'),
(375, 'c856648dd4', 'Mya Mya', '1993-10-05', 'present', '0912345678', 'mandalay', 'appointment.jpg', '2024-06-13', 70, 'htmlcssphp', 'no'),
(376, 'c856648dd4', 'Mya Mya', '1993-10-05', 'present', '0912345678', 'mandalay', 'appointment.jpg', '2024-06-18', 70, 'htmlcssphp', 'no'),
(377, 'c856648dd4', 'Mya Mya', '1993-10-05', 'present', '0912345678', 'mandalay', 'appointment.jpg', '2024-06-19', 70, 'htmlcssphp', 'no'),
(378, 'c856648dd4', 'Mya Mya', '1993-10-05', 'absent', '0912345678', 'mandalay', 'appointment.jpg', '2024-06-20', 70, 'htmlcssphp', 'no'),
(379, 'c856648dd4', 'Mya Mya', '1993-10-05', 'present', '0912345678', 'mandalay', 'appointment.jpg', '2024-06-25', 70, 'htmlcssphp', 'no'),
(380, 'c856648dd4', 'Mya Mya', '1993-10-05', 'present', '0912345678', 'mandalay', 'appointment.jpg', '2024-06-26', 70, 'htmlcssphp', 'no'),
(381, 'c856648dd4', 'Mya Mya', '1993-10-05', 'present', '0912345678', 'mandalay', 'appointment.jpg', '2024-06-27', 70, 'htmlcssphp', 'no'),
(382, '55fe92625a', 'Aung Aung', '2000-10-25', 'present', '09123456780', 'yangon', 'carousel-1.jpg', '2024-06-05', 70, 'htmlcssphp', 'no'),
(383, '55fe92625a', 'Aung Aung', '2000-10-25', 'present', '09123456780', 'yangon', 'carousel-1.jpg', '2024-06-06', 70, 'htmlcssphp', 'no'),
(384, '55fe92625a', 'Aung Aung', '2000-10-25', 'present', '09123456780', 'yangon', 'carousel-1.jpg', '2024-06-11', 70, 'htmlcssphp', 'no'),
(385, '55fe92625a', 'Aung Aung', '2000-10-25', 'present', '09123456780', 'yangon', 'carousel-1.jpg', '2024-06-12', 70, 'htmlcssphp', 'no'),
(386, '55fe92625a', 'Aung Aung', '2000-10-25', 'present', '09123456780', 'yangon', 'carousel-1.jpg', '2024-06-13', 70, 'htmlcssphp', 'no'),
(387, '55fe92625a', 'Aung Aung', '2000-10-25', 'present', '09123456780', 'yangon', 'carousel-1.jpg', '2024-06-18', 70, 'htmlcssphp', 'no'),
(388, '55fe92625a', 'Aung Aung', '2000-10-25', 'absent', '09123456780', 'yangon', 'carousel-1.jpg', '2024-06-19', 70, 'htmlcssphp', 'no'),
(389, '55fe92625a', 'Aung Aung', '2000-10-25', 'present', '09123456780', 'yangon', 'carousel-1.jpg', '2024-06-20', 70, 'htmlcssphp', 'no'),
(390, '55fe92625a', 'Aung Aung', '2000-10-25', 'present', '09123456780', 'yangon', 'carousel-1.jpg', '2024-06-25', 70, 'htmlcssphp', 'no'),
(391, '55fe92625a', 'Aung Aung', '2000-10-25', 'present', '09123456780', 'yangon', 'carousel-1.jpg', '2024-06-26', 70, 'htmlcssphp', 'no'),
(392, '55fe92625a', 'Aung Aung', '2000-10-25', 'present', '09123456780', 'yangon', 'carousel-1.jpg', '2024-06-27', 70, 'htmlcssphp', 'no'),
(393, '299cc846ef', 'Aye Aye', '1996-06-04', 'present', '09123456780', 'yangon', 'classes-1.jpg', '2024-08-12', 72, 'Yoga', 'new'),
(394, 'fd59265d5c', 'mg mg', '1990-10-03', 'present', '09123456780', 'yangon', 'about-2.jpg', '2024-09-03', 74, 'English', 'new'),
(395, 'e0a25fb42a', 'mg mg', '1990-10-03', 'present', '09123456789', 'yangon', 'about-2.jpg', '2024-09-07', 75, 'Pythondjango', 'new');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
