<!DOCTYPE html>
<html>
<head>



    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title></title>

    <meta charset="utf-8">
    <title>AI school Website</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Heebo:wght@400;500;600&family=Inter:wght@600&family=Lobster+Two:wght@700&display=swap" rel="stylesheet">
    
    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/animate/animate.min.css" rel="stylesheet">
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="css/anistyle.css">
</head>
<body class="bg-white">
   
 <div class="container-xxl bg-white p-0">
        <!-- Spinner Start -->
        <div id="spinner" class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
            <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status">
                <span class="sr-only">Loading...</span>
            </div>
        </div>
        <!-- Spinner End -->


        <!-- Navbar Start -->
        <nav class="navbar navbar-expand-lg bg-white navbar-light sticky-top px-4 px-lg-5 py-lg-0">
            <img src="img/school.png" height="50px" class="vibrate-1">
            <a href="#" class="navbar-brand">

                <h1 class="m-0 text-secondary">AI School</h1>
            </a>
            <button type="button" class="navbar-toggler" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarCollapse">
                <div class="navbar-nav mx-auto">
                    <a href="index.php" class="nav-item nav-link text-primary">Home</a>
                    <a href="ourteacher.php" class="nav-item nav-link text-secondary">Our Great Teachers</a>
                    <a href="outstandingstudentboostrap.php" class="nav-item nav-link text-secondary">Our Outstanding Students</a>
                    <a href="user/index.php" class="nav-item nav-link text-secondary">Students Register!</a>
                    <div class="nav-item dropdown">
                        <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">Authority</a>
                        <div class="dropdown-menu rounded-0 rounded-bottom border-0 shadow-sm m-0">
                            <a href="admin/index.php" class="dropdown-item">Admin</a>
                            
                        </div>
                    </div>
                    <a href="readme.php" class="nav-item nav-link">Read me!</a>

                </div>
                <a href="readme1.php" class="btn btn-primary rounded-pill px-3 d-none d-lg-block">How to use!<i class="fa fa-arrow-right ms-3"></i></a>
            </div>
        </nav>
        <!-- Navbar End -->
</div>


        <!-- Carousel Start -->
        <div class="container-fluid p-0 mb-5 ">
            <div class="owl-carousel header-carousel position-relative">
                <div class="owl-carousel-item position-relative">

                    <img class="img-fluid" src="img/carousel-3.jpg" alt="">
                    <div class="position-absolute top-0 start-0 w-100 h-100 d-flex align-items-center" style="background: rgba(0, 0, 0, .2);">
                        <div class="container">



<center><a href="http://www.kwt3.pmojt.com/" class="nav-item nav-link text-white"><img src="img/pkm.gif" class="rounded-circle " style="height: 100px; width: 100px;"><p class="vibrate-1"><b> Gift(Please open it!)</b></p></a></center>
    
                            <div class="row justify-content-start align-items-start">
                                <div class="col col-lg-10">
                                    <h1 class="display-2 text-white animated slideInDown mb-4">The Best AI ,IT, Yoga, Music, English language Schools For You</h1>
                                    <p class="fs-5 fw-medium text-white mb-4 pb-2">A school is both the educational institution and building designed to provide learning spaces and learning environments for the teaching of students under the direction of teachers. Most countries have systems of formal education, which is sometimes compulsory.</p>
                                    <!--<a href="#" class="btn btn-primary rounded-pill py-sm-3 px-sm-5 me-3 animated slideInLeft">-->
                                        

                                        <!-- <div class="carousel-caption d-none d-md-block">-->
      
      
                                        <!--<h2 class="a">About us</h2>-->
                                            <div >
                                    <img class="img-fluid" src="img/robot-unscreen.gif" alt="" style="width:100px; height: 100px;">
                                </div><br><br>
                                           
                                       <button class="btn btn-primary rounded-pill py-sm-3 px-sm-5 me-3 animated slideInLeft" type="button" data-bs-toggle="collapse" data-bs-target="#collapseExample" aria-expanded="false" aria-controls="collapseExample">
                                                                Our School(Click here!)
                                               </button>
                                              
                                         <div class="collapse" id="collapseExample">
                                         <div class="card card-body bg-dark text-white">
    
                                    Our Schools are organized spaces purposed for teaching and learning. The classrooms where teachers teach and students learn are of central importance. Classrooms may be specialized for certain subjects, such as laboratory classrooms for science education and workshops for industrial arts education.
                                  
       
                                        </div>
                                            </div>
      
      
                                       
      
        
      <!--</div>-->
                                   <!-- </a>-->
                                    <!--<a href="" class="btn btn-dark rounded-pill py-sm-3 px-sm-5 animated slideInRight">Our Classes</a>-->

                                     
                                </div>
                                
                            </div>
                        </div>
                    </div>
                </div>
                <div class="owl-carousel-item position-relative">
                    <img class="img-fluid" src="img/carousel-4.jpg" alt="">
                    <div class="position-absolute top-0 start-0 w-100 h-100 d-flex align-items-center" style="background: rgba(0, 0, 0, .2);">
                        <div class="container">

 <div class="row">

                                    <div class="col-sm-2"></div>
<div class="col-sm-2">
<a href="http://www.kwt3.pmojt.com/" class="nav-item nav-link text-white"><img src="https://i.gifer.com/AJdf.gif" class="rounded-circle " style="height: 100px; width: 100px;"><p class="vibrate-1"><b> Gift(Please open it!)</b></p></a></div>
                                </div>



    
                            <div class="row justify-content-start">
                                <div class="col-10 col-lg-8">
                                    <h5 class="display-2 text-white animated slideInDown mb-4">Make A Brighter Healthier Future For You</h5>
                                    <p class="fs-5 fw-medium text-white mb-4 pb-2">Yoga is a group of physical, mental, and spiritual practices or disciplines which originated in ancient India and aim to control (yoke) and still the mind, ...</p>
<div><img class="img-fluid" src="img/yoga-unscreen.gif" alt="" style="width:50px; height:50px;"></div><br><br>
                                    
                                    <button class="btn btn-dark rounded-pill py-sm-3 px-sm-5 me-3 animated slideInLeft" type="button" data-bs-toggle="collapse" data-bs-target="#collapseExample1" aria-expanded="false" aria-controls="collapseExample">
                                                                Our Classes(click me!)
                                               </button>
                                              
                                         <div class="collapse" id="collapseExample1">
                                         <div class="card card-body bg-info text-white">
                                          Yoga ,computer, English language , Guitar and music are available here!
    
                                  
       
                                        </div>
                                            </div>
                                     
                                     


                                </div>
                                 
                            </div>
                        </div>
                    </div>

                    
                </div>
            </div>
       
    
        <!-- Carousel End -->
        <?php include('footer.php') ?>
 </div>
         <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="lib/wow/wow.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/waypoints/waypoints.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>

    <!-- Template Javascript -->
    <script src="js/main.js"></script>

</body>
</html>