 
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title></title>
</head>
<body>
<?php 
include('booststyleconnect/styleconnection.php');
include('adminuserheader.php');
?>

 <div class="container-xxl py-5 ">
            <div class="container ">
                <div class="text-center mx-auto mb-5 wow fadeInUp" data-wow-delay="0.1s" style="max-width: 600px;">
                    <h1 class="mb-3">Our School Admins</h1>
                    <p>School administrators are essential for the effective functioning of educational institutions. They oversee daily operations, manage staff and resources, and implement policies and procedures. Their main goal is to create a positive learning environment and promote academic excellence.</p>
                </div>
                <div class="row g-4">
                    <div class="col-lg-3 col-sm-6 wow fadeInUp" data-wow-delay="0.1s">
                        <div class="facility-item">
                            <div class="facility-icon bg-primary">
                                <span class="bg-primary"></span>
                                <i class="fa fa-bus-alt fa-3x text-primary"></i>
                                <span class="bg-primary"></span>
                            </div>
                            <div class="facility-text bg-primary">
                                <h3 class="text-primary mb-3">School Boss</h3>
                                <p class="mb-0"><button type="button" class="btn btn-outline-success"> <a href="boss/index.php" class="nav-item nav-link text-secondary">Boss</a></button></p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-sm-6 wow fadeInUp" data-wow-delay="0.3s">
                        <div class="facility-item">
                            <div class="facility-icon bg-success">
                                <span class="bg-success"></span>
                                <i class="fa fa-futbol fa-3x text-success"></i>
                                <span class="bg-success"></span>
                            </div>
                            <div class="facility-text bg-success">
                                <h3 class="text-success mb-3">Headofficer</h3>
                                <p class="mb-0"><button type="button" class="btn btn-outline-primary"> <a href="headofficer/index.php" class="nav-item nav-link text-secondary">Headofficer</a></button></p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-sm-6 wow fadeInUp" data-wow-delay="0.5s">
                        <div class="facility-item">
                            <div class="facility-icon bg-warning">
                                <span class="bg-warning"></span>
                                <i class="fa fa-home fa-3x text-warning"></i>
                                <span class="bg-warning"></span>
                            </div>
                            <div class="facility-text bg-warning">
                                <h3 class="text-warning mb-3">Register Admin</h3>
                                <p class="mb-0"> <button type="button" class="btn btn-outline-primary"><a href="registeradmin/index.php" class="nav-item nav-link text-secondary">RegisterAdmin</a></button></p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-sm-6 wow fadeInUp" data-wow-delay="0.7s">
                        <div class="facility-item">
                            <div class="facility-icon bg-info">
                                <span class="bg-info"></span>
                                <i class="fa fa-chalkboard-teacher fa-3x text-info"></i>
                                <span class="bg-info"></span>
                            </div>
                            <div class="facility-text bg-info">
                                <h3 class="text-info mb-3">Office Admin</h3>
                                <p class="mb-0"><button type="button" class="btn btn-outline-secondary"> <a href="officeadmin/index.php" class="nav-item nav-link text-secondary">officeadmin</a></button></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Facilities End -->


</body>
</html>
