<?php
include('connection.php');
include('redirect.php');
$q = "DELETE FROM studentlist WHERE id='{$_GET['id']}'";
$con->query($q);
unlink("../../user/image/".$_GET['sid']."/".$_GET['img']);
rmdir("../../user/image/".$_GET['sid']);
header('location:display.php');
?>