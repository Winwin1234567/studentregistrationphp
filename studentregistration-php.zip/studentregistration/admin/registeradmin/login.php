<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
	


</head>
<style type="text/css">
	body{
	margin:0;
	color:#6a6f8c;
	background:#c8c8c8;
	font:600 16px/18px 'Open Sans',sans-serif;
}

.login-box{
	width:100%;
	margin:auto;
	max-width:525px;
	min-height:670px;
	position:relative;
	
	box-shadow:0 12px 15px 0 rgba(0,0,0,.24),0 17px 50px 0 rgba(0,0,0,.19);
}
.login-snip{
	width:100%;
	height:100%;
	position:absolute;
	padding:90px 70px 50px 70px;
	background:rgba(0, 77, 77,.9);
}
.login-snip .login,
.login-snip .sign-up-form{
	top:0;
	left:0;
	right:0;
	bottom:0;
	position:absolute;
	transform:rotateY(180deg);
	backface-visibility:hidden;
	transition:all .4s linear;
}
.login-snip .sign-in,
.login-snip .sign-up,
.login-space .group .check{
	display:none;
}
.login-snip .tab,
.login-space .group .label,
.login-space .group .button{
	text-transform:uppercase;
}
.login-snip .tab{
	font-size:22px;
	margin-right:15px;
	padding-bottom:5px;
	margin:0 15px 10px 0;
	display:inline-block;
	border-bottom:2px solid transparent;
}
.login-snip .sign-in:checked + .tab,
.login-snip .sign-up:checked + .tab{
	color:#fff;
	border-color:#1161ee;
}
.login-space{
	min-height:345px;
	position:relative;
	perspective:1000px;
	transform-style:preserve-3d;
}
.login-space .group{
	margin-bottom:15px;
}
.login-space .group .label,
.login-space .group .input,
.login-space .group .button{
	width:100%;
	color:#fff;
	display:block;
}
.login-space .group .input,
.login-space .group .button{
	border:none;
	padding:15px 20px;
	border-radius:25px;
	background:rgba(255,255,255,.1);
}
.login-space .group input[data-type="password"]{
	text-security:circle;
	-webkit-text-security:circle;
}
.login-space .group .label{
	color:#aaa;
	font-size:12px;
}
.login-space .group .button{
	background:#1161ee;
}
.login-space .group label .icon{
	width:15px;
	height:15px;
	border-radius:2px;
	position:relative;
	display:inline-block;
	background:rgba(255,255,255,.1);
}
.login-space .group label .icon:before,
.login-space .group label .icon:after{
	content:'';
	width:10px;
	height:2px;
	background:#fff;
	position:absolute;
	transition:all .2s ease-in-out 0s;
}
.login-space .group label .icon:before{
	left:3px;
	width:5px;
	bottom:6px;
	transform:scale(0) rotate(0);
}
.login-space .group label .icon:after{
	top:6px;
	right:0;
	transform:scale(0) rotate(0);
}
.login-space .group .check:checked + label{
	color:#fff;
}
.login-space .group .check:checked + label .icon{
	background:#1161ee;
}
.login-space .group .check:checked + label .icon:before{
	transform:scale(1) rotate(45deg);
}
.login-space .group .check:checked + label .icon:after{
	transform:scale(1) rotate(-45deg);
}
.login-snip .sign-in:checked + .tab + .sign-up + .tab + .login-space .login{
	transform:rotate(0);
}
.login-snip .sign-up:checked + .tab + .login-space .sign-up-form{
	transform:rotate(0);
}

*,:after,:before{box-sizing:border-box}
.clearfix:after,.clearfix:before{content:'';display:table}
.clearfix:after{clear:both;display:block}
a{color:inherit;text-decoration:none}


.hr{
	height:2px;
	margin:60px 0 50px 0;
	background:rgba(255,255,255,.2);
}
.foot{
	text-align:center;
}
.card{
	width: 500px;
	left: 100px;
}

::placeholder{
color: #b3b3b3;
} 
</style>

<body>

	

<div class ="row">
	<div class="col-md-6 mx-auto p-0">
		<div class="card">

<div class="login-box">

	<div class="login-snip">
		

		<input id="tab-1" type="radio" name="tab" class="sign-in" checked><label for="tab-1" class="tab">Login</label>
		<input id="tab-2" type="radio" name="tab" class="sign-up"><label for="tab-2" class="tab">Sign Up</label>
		
			

        <div class="login-space">
			<form method="post">
			<div class="login">
				<?php

@$id = $_POST['id'];
@$pass = $_POST['pass'];

if (isset($_POST['signin'])) {
	if ($id=="admin" && $pass =="123") {
         
		
     setcookie("cid",$id,time()+30*30);
     



		header("location:display.php");
		// code...
	}else{

		 

		echo " wrong id and pass!",
		"try again later!";
	}
	// code...
}
?>
				<div class="group">
					<label for="user" class="label">Username</label>
					<input id="user" type="text" class="input"  name="id" placeholder="Enter your username">
				</div>
				<div class="group">
					<label for="pass" class="label">Password</label>
					<input id="pass" type="password" class="input" name="pass" data-type="password" placeholder="Enter your password">
				</div>
				
				<div class="group">
					<input type="submit" class="button" name="signin"  value="Sign In">
				</div>
				</form>

				<div class="hr"></div>
				<div class="right-side">
        <div class="d-grid gap-2 d-md-flex justify-content-md-end">
<button class="btn btn-outline-light "><a href="index.php" class="dropdown-item text-white"><i class="bi bi-airplane-engines"></i><i class="bi bi-door-open"></i><i class="bi bi-android"><i class="bi bi-bar-chart-fill"></i></i> < Back</a></button><br><br>
</div>
</div> 
			</div>
			
		</div>
	</div>
</div>


</div>
</div>
</div>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>

	<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.min.js" integrity="sha384-0pUGZvbkm6XF6gxjEnlmuGrJXVbNuzT9qBBavbLwCsOGabYfZo0T0to5eqruptLy" crossorigin="anonymous"></script>

<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-icons/1.11.3/font/bootstrap-icons.min.css">

</body>
</html>


