
<head>
	
	<link rel="stylesheet" type="text/css" href="">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>

	<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>

	<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.min.js" integrity="sha384-0pUGZvbkm6XF6gxjEnlmuGrJXVbNuzT9qBBavbLwCsOGabYfZo0T0to5eqruptLy" crossorigin="anonymous"></script>



<script type="text/javascript" src="https://cdn.datatables.net/2.0.8/js/dataTables.js"></script>

<script type="text/javascript" src="https://cdn.datatables.net/2.0.8/js/dataTables.bootstrap4.js"></script>
<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.2/css/bootstrap.css">
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/2.0.8/css/dataTables.bootstrap4.css">
</head>

<style type="text/css">
	
</style>
<body>
	<center>
	<br>
	<h1>Old Student Register!</h1>
	
</center>

<div class="row">
	<div class="col-sm-1"></div>
  	<div class="col-sm-4">

  		<table  id="example" class="table table-hover table-sm">
	<thead class=" table-bordered ">


	<tr>
		     <td>New Class ID</td>
			
			<td>New Class name</td>
			
			<td>Timetable</td>
			<td>Starting date</td>
			
			<td>Accepting Student</td>
			
			
		
	</tr>

	</thead>

	<tbody class="table table-bordered  table-sm ">
	<?php
	error_reporting(1);
	include('connection.php');
	
	$q = "SELECT * FROM classlist";
	$val = $con->query($q);
	while (list($classid,$classname,$timetable,$startingdate,$acceptingstudent,$classimg,$coursesummary) = mysqli_fetch_array($val)) {

		echo"<tr>";
		echo "<td >".$classid."</td>";
		
			echo "<td >".$classname."</td>";
				echo "<td >".$timetable."</td>";
				
					
						echo "<td>".$startingdate."</td>";
						echo "<td>".$acceptingstudent."</td>";
							

						
							echo"</tr>";
				}
		# code...
	

	?>


</tbody>
</table>
  		
  	</div>
<div class="col-sm-1"></div>

<div class="col-sm-4 mt-3">
	<center>
	<a href="index.php" role="button" class="btn btn-outline-secondary">Back</a>
	<a href="display.php" role="button" class="btn btn-outline-warning">Display</a>
	<a href="logout.php" class="btn btn-outline-info">log out!</a><br><br>

	<?php
error_reporting(1);
include('connection.php');
include('redirect.php');



@$id = $_GET['id'];
$val = $con->query("SELECT * FROM studentlist WHERE id=$id");
$data = mysqli_fetch_array($val);



@$classid1 = $_POST['cididid'];

@$classname = $_POST['cnn'];



$q2 = "SELECT * FROM classlist WHERE classid= '$classid1'";
	$val2 = $con->query($q2);
$data2 = mysqli_fetch_array($val2);

extract($_POST);
if (isset($sub)) {


  
   if ($data2['acceptingstudent']<= 0) {

    	 echo"<font color='red'>invalid class id and name!.OR Already fulled Student numbers!.</font><br>";
    	
    }

    elseif($data2['classid'] == $classid1 AND $data2['classname'] == $classname)
    {
  

@$classid = $_POST['cididid'];
	$rawdate = htmlentities($_POST['sdob']);
$date = date('Y-m-d', strtotime($rawdate));


 $rawdatead = htmlentities($_POST['ad']);
$datead = date('Y-m-d', strtotime($rawdatead));

	$con->query("insert into studentlist values ('','$sid','$sn','$date','$ss', '$sm','$sc','$img','$datead','$cididid','$cnn','$no')");

	 $sql = "UPDATE classlist SET acceptingstudent = (acceptingstudent -1) WHERE classid = '$classid'";
    $con->query($sql);
    
	header('location:display.php');
	# code...
} else{

	echo"<font color='red'>invalid!</font>";
}
}


	# code...


?>
</center>
	<div class="container border" style="max-width: 700px;background-color:lightskyblue;">
<form method="post" enctype="multipart/form-data">
Enter Student ID<input type="text" class="form-control" name="sid"  value="<?php echo $data['studentid']?>" readonly /><br>
Enter Student Name<input type="text " class="form-control" name="sn" value="<?php echo $data['studentname']?>"readonly/><br>
Enter Student Date of Birth<input type="date " class="form-control" name="sdob" value="<?php echo $data['studentdob']?>" readonly/><br>
Enter Status <select class="form-select" name="ss"><option>present</option>
                               <option>absent</option>
                               
                           </select required><br>

Enter Attendance Date 

<input type="date" 
        placeholder="yyyy-mm-dd" 
        min="1970-01-01" max="2030-12-31" class="form-control" id="date"  name="ad" value="<?php echo $data['attendance_date']?>"  required/>  

        <br><br>
Enter Mobile <input type="number " class="form-control" name="sm" value="<?php echo $data['mobile']?>" readonly/><br>
Enter City <input type="text " class="form-control" name="sc" value="<?php echo $data['city']?>" readonly/><br>
Enter image <input type="text " class="form-control" name="img" value="<?php echo $data['img']?>" readonly/><br>

               

Enter Existing Class Id <input type="text" class="form-control" name="cididid" value="" required/><br>

Enter Existing Class Name <input type="text" class="form-control" name="cnn" value="" required/><br>

 <input type="hidden" class="form-control" name="as" value="<?php echo $data1['acceptingstudent']?>" readonly/><br>
Enter Course Completion status <input type="text " class="form-control" name="no" value="new" readonly/>


<br>
<input type="submit" name="sub" value="INSERT Old Student!" role='button' class="btn btn-primary" />
</form>
</div>
  </div>
 <div class="col-sm-2">
</div>

</div>
<script type="text/javascript">
	


	$(document).ready(function() {
    $('#example').DataTable();
} );

</script>

</body>