<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>



<script type="text/javascript" src="https://cdn.datatables.net/2.0.8/js/dataTables.js"></script>

<script type="text/javascript" src="https://cdn.datatables.net/2.0.8/js/dataTables.bootstrap4.js"></script>
<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.2/css/bootstrap.css">
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/2.0.8/css/dataTables.bootstrap4.css">




	
	<link rel="stylesheet" type="text/css" href="">
</head>
<style type="text/css">
	

</style>
<body class="bg-dark">
	<center>
	<br>
	<h1 style="color: white;">Students Information</h1>
	<a href="index.php" role="button" class="btn btn-outline-secondary text-white">< Back</a>
	<a href="#" role="button" class="btn btn-outline-warning text-white">Display</a>

	<a href="logout.php" class="btn btn-outline-light">log out register admin!</a>


	<div class="table-responsive-sm">
<table  id="example" class="table table-hover table-sm">
	<thead class="table-borderless text-white">


	<tr>
		     <td>ID</td>
			<td>Student ID</td>
			<td>Student name</td>
			<td>Student Date of birth</td>
			
			<td>mobile</td>
			<td>City</td>
			
			<td>Student photos</td>
			<td>Photo name</td>
			<td>Starting Attendance date</td>
			<td>Class Data</td>
			<td>delete</td>
			<td>multipleedit</td>
			<td>Old student register</td>
			<td>Complete status</td>
			
		
	</tr>

	</thead>
<tbody class="table table-bordered  table-sm ">
	<?php
	error_reporting(1);
	include('connection.php');
	include('redirect.php');
	$q = "SELECT * FROM studentlist";
	$val = $con->query($q);
	while (list($id,$studentid,$studentname,$studentdob,$status,$mobile,$city,$img,$attendance_date,$classidid,$classnamename,$completestatus) = mysqli_fetch_array($val)) {

		echo"<tr>";
		echo "<td >".$id."</td>";
		//echo "<td >".$studentid."</td>";

                           if ($completestatus == "new") {
					// code...
					echo "<td ><font color='red'>".$studentid."</font></td>";
				}elseif ($completestatus == "no") {
					// code...
					echo "<td ><font color='green'>".$studentid."</font></td>";
				}elseif($completestatus=="yes"){

					echo "<td ><font color='gold'>".$studentid."</font></td>";
				}
			echo "<td >".$studentname."</td>";
				echo "<td >".$studentdob."</td>";
				
					
						echo "<td>".$mobile."</td>";
						echo "<td>".$city."</td>";
							
							echo "<td><img src='../../user/image/$studentid/$img' height='100' width='100'/></td>";
                          echo "<td>".$img."</td>";
							echo "<td>".$attendance_date."</td>";
							echo "<td>".$classidid." ".$classnamename."</td>";
							echo "<td><a onclick='return confirm(\"Are you sure?\")' href='delete.php?id=$id&sid=$studentid&img=$img' role='button' class='btn btn-outline-danger'>DELETE</a></td>";
							echo "<td><a href='edit.php?id=$studentid' role='button' class='btn btn-outline-warning'>multipleEdit</a></td>";
							echo "<td><a href='rollcall.php?id=$id&cidid=$classidid' role='button' class='btn btn-outline-secondary'>register_old_student!</a></td>";
							echo"<td>".$completestatus."</td>";
							echo"</tr>";
				}
		# code...
	

	?>


</tbody>
</table>
</div>
</center>
<center>
<?php
error_reporting(1);


extract($_POST);

if($sub1) {


$simg=$_FILES['simg']['name'];








     mkdir("../../user/image/$sid");
    move_uploaded_file($_FILES['simg']['tmp_name'],"../../user/image/$sid/".$_FILES['simg']['name']);
    

    echo "<font color='blue' align='center'>Congrates deleted student photo insertion Complete!</font>";
    
}

	# code...


?>
</center>



	<div class="row">
  	<div class="col-sm-4">
  		
  	</div>


<div class="col-sm-4 mt-3">
	<div class="container border" style="max-width: 300px;background-color:orangered;">
<form method="post" enctype="multipart/form-data">

Copy Deleted student id<input type="text " class="form-control" name="sid" required/><br>


Choose Deleted Student Image & same image name<input type="file" class="form-control-file" name="simg" required/><br>


<input type="submit" name="sub1" value="Student photos insert" class="btn btn-primary" />
</form>
</div>
  </div>
 <div class="col-sm-4">
</div>

</div>

</body>
<script type="text/javascript">
	


	$(document).ready(function() {
    $('#example').DataTable();
} );

</script>