
<head>
	
	<link rel="stylesheet" type="text/css" href="">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>

	<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.min.js" integrity="sha384-0pUGZvbkm6XF6gxjEnlmuGrJXVbNuzT9qBBavbLwCsOGabYfZo0T0to5eqruptLy" crossorigin="anonymous"></script>
</head>

<style type="text/css">
	
</style>
<body>
	<center>
	<br>
	<h1>Single data Student Update Form!</h1>
	<a href="display.php" role="button" class="btn btn-outline-secondary">Back</a>
	<a href="#" role="button" class="btn btn-outline-warning">Update</a>
	<a href="logout.php" class="btn btn-outline-primary">logout here!</a>
</center>
<?php
error_reporting(1);

include('connection.php');
include('redirect.php');



$id = $_GET['id'];
$val = $con->query("SELECT * FROM studentlist WHERE id='$id'");
$data = mysqli_fetch_array($val);

extract($_POST);
if (isset($sub)) {

	$rawdate = htmlentities($_POST['sdob']);
$date = date('Y-m-d', strtotime($rawdate));


 $rawdatead = htmlentities($_POST['ad']);
$datead = date('Y-m-d', strtotime($rawdatead));

	$con->query("update studentlist set studentid='$sid',studentname='$sn',studentdob='$date',status='$ss',mobile = '$sm',city='$sc',attendance_date='$datead',completestatus='$no' where id='$id'");
	header('location:display.php');
	# code...
}


	# code...


?>
<div class="row">
  	<div class="col-sm-4">
  		
  	</div>


<div class="col-sm-4 mt-3">
	<div class="container border" style="max-width: 700px;background-color:lightskyblue;">


<form method="post" enctype="multipart/form-data">




<label for="Student ID">Student ID:</label><input type="text" class="form-control" name="sid"  value="<?php echo $data['studentid']?>" readonly /><br>
<label for="Student Name">Student Name:</label><input type="text " class="form-control" name="sn" value="<?php echo $data['studentname']?>"readonly/><br>
<label for="Student date of birth">Student date of birth:</label><input type="date " class="form-control" name="sdob" value="<?php echo $data['studentdob']?>" readonly/><br>

<label for="Attendance date">Attendance Date:</label> 

<input type="date" 
        placeholder="yyyy-mm-dd" 
        min="1970-01-01" max="2030-12-31" class="form-control" id="date"  name="ad" value="<?php echo $data['attendance_date']?>"  required/>  

        <br><br>
<label for="Status">Status:</label> <select class="form-select" name="ss"><option>present</option>
                               <option>absent</option>
                               
                           </select><br>
 <label for="mobile">Mobile:</label><input type="number " class="form-control" name="sm" value="<?php echo $data['mobile']?>" readonly/><br>
<label for="City">City:</label> <input type="text " class="form-control" name="sc" value="<?php echo $data['city']?>" readonly/><br>

Enter Certified status <select class="form-select" name="no">
	                             <option>new</option>
	                           <option>no</option>
                               <option>yes</option>
                               
                           </select><br>



<input type="submit" name="sub" value="INSERT single Update" role='button' class="btn btn-primary" />
</form>
</div>
  </div>
 <div class="col-sm-4">
</div>

</div>
</body>