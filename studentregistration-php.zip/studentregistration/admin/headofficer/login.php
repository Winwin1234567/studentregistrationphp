<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>

	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>

	<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.min.js" integrity="sha384-0pUGZvbkm6XF6gxjEnlmuGrJXVbNuzT9qBBavbLwCsOGabYfZo0T0to5eqruptLy" crossorigin="anonymous"></script>

<!-- Option 1: Include in HTML -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.3.0/font/bootstrap-icons.css">
</head>
<style type="text/css">
	
  body {
  background-image: url("https://snappygoat.com/b/f0bd5343b440f52b8a6fc13bee1ff5590e964cf7");
  background-repeat: no-repeat;
  background-attachment: fixed;
  background-size: cover;
  overflow: hidden;
  margin: 0;
  padding: 0;
}



#rainy-container {
  position: absolute;
  top:0;
  left:0;
  right:0;
  bottom:0;
  height: 100vh;
  overflow: hidden;
}

.raindrop {

  border-radius: 50%;
  position: absolute;
  width: 3px;
  height: 1em;
  background: linear-gradient(to bottom, transparent, rgba(255, 255, 250, 0.75));
  animation: raindrop-animation 1s linear infinite;
}

@keyframes raindrop-animation {
  0% {
    transform: translateY(-10vh);
  }
  100% {
    transform: translate(-5vw, 110vh);
  }
}

@import url('https://fonts.googleapis.com/css?family=Raleway:400,700');
/* Option 2: Import via CSS */


.login {
  margin: 30px auto;
  padding: 50px 50px;
  max-width: 350px;
  border-radius: 5px;
  background: #fff;
  box-shadow: 1px 1px 1px #666;
}
  .login input {
    width: 100%;
    display: block;
    box-sizing: border-box;
    margin: 10px 0;
    padding: 14px 12px;
    font-size: 16px;
    border-radius: 2px; 
    font-family: Raleway, sans-serif;
  }

.login input[type=text],
.login input[type=password] {
  border: 1px solid #c0c0c0;
  transition: .2s;
}

.login input[type=text]:hover {
  border-color: #F44336;
  outline: none;
  transition: all .2s ease-in-out;
} 

.login input[type=submit] {
  border: none;
  background: blueviolet;
  color: white;
  font-weight: bold;  
  transition: 0.2s;
  margin: 20px 0px;
}

.login input[type=submit]:hover {
  background: #F44336;  
}

  .login h2 {
    margin: 20px 0 0; 
    color: blue;
    font-size: 28px;
  }

.login p {
  margin-bottom: 40px;
}

.links {
  display: table;
  width: 100%;  
  box-sizing: border-box;
  border-top: 1px solid #c0c0c0;
  margin-bottom: 10px;
}

.links a {
  display: table-cell;
  padding-top: 10px;
}

.links a:first-child {
  text-align: left;
}

.links a:last-child {
  text-align: right;
}

  .login h2,
  .login p,
  .login a {
    text-align: center;    
  }

.login a {
  text-decoration: none;  
  font-size: .8em;
}

.login a:visited {
  color: inherit;
}

.login a:hover {
  text-decoration: underline;
}

</style>

<?php

@$id = $_POST['id'];
@$pass = $_POST['pass'];

if (isset($_POST['signin'])) {
	if ($id=="admin" && $pass =="123") {
         
		
     setcookie("cid",$id,time()+30*30);
     



		header("location:display.php");
		// code...
	}else{

		 

		echo " wrong id and pass!",
		"try again later!";
	}
	// code...
}
?>


<body>	

<div id="rainy-container">
	<!-- Raindrop elements will be added here -->
	
</div>

<div id="rainy-container">
	<!-- Raindrop elements will be added here -->
	

<br><br><br>
<form class="login" method="post">
	 <div class="d-grid gap-2 d-md-flex justify-content-md-end">
<button class="btn btn-outline-secondary "><a href="index.php"><i class="bi bi-door-open"></i> < Back</a></button><br><br>
</div>
  <h2>Welcome,Headofficer!</h2>
  <p>Please log in</p>
  <input type="text" placeholder="User Name"  name="id"/>
  <input type="password" placeholder="Password" name="pass" />
  <input type="submit" value="Log In" name="signin" />
  
</form>

</div>



<script type="text/javascript">
	const rainyContainer = document.getElementById("rainy-container");

function createRaindrop() {
	// Create a new raindrop element
	const raindrop = document.createElement("div");
	raindrop.classList.add("raindrop");

	// Generate a random number between 0 and the width of the container
	const x = Math.floor(Math.random() * rainyContainer.offsetWidth);

	// Set the position of the raindrop using the generated x value
	raindrop.style.left = `${x}px`;

	// Add the raindrop to the container
	rainyContainer.appendChild(raindrop);
}

// Create a new raindrop every 55 milliseconds
setInterval(createRaindrop, 25);
</script>
</body>
</html>


