<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>

	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>

	<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.min.js" integrity="sha384-0pUGZvbkm6XF6gxjEnlmuGrJXVbNuzT9qBBavbLwCsOGabYfZo0T0to5eqruptLy" crossorigin="anonymous"></script>

<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-icons/1.11.3/font/bootstrap-icons.min.css">

</head>
<style type="text/css">
	* {
	padding: 0;
	margin: 0;
}
html,
body {
	overflow: hidden;
}


#container {
	width: 100vw;
	height: 100vh;
	position: relative;
}

.leaf {
	/* Adiciona um estilo de transição para suavizar a animação */
	animation-duration: 12s;
	animation-name: falling;
	/* Posiciona a folha no topo da tela */
	position: absolute;
	top: -60px;
	/* Define o tamanho da imagem */
	width: 50px;
	height: 50px;
}

.leaf img {
	width: 50px;
	height: 50px;
}

/* Define a animação da folha */
@keyframes falling {
	/* A folha começa no topo da tela */
	0% {
		margin-top: 0;
	}

	20% {
		transform: rotate(70deg);
	}
	50% {
		transform: rotate(-20deg);
	}
	/* A folha se move para baixo até o final da tela */
	100% {
		margin-top: 130vh;
		transform: rotate(80deg);
	}
}

.botoes {
	display: flex;
	flex-direction: row;
	position: absolute;
	top: 85%;
	left: 5%;
	justify-content: center;
	align-items: center;
	margin: auto;
	gap: 20px;
}

.botoes button {
	width: 40px;
	height: 40px;
	border-radius: 20px;
	cursor: pointer;
}

</style>

<body>
<div id="container">

	<!-- O container será preenchido com folhas caindo -->


	
<form method="post">

<section class="vh-100" style="background-color: #508bfc;">
  <div class="container py-5 h-100">
    <div class="row d-flex justify-content-center align-items-center h-100">
      <div class="col-12 col-md-8 col-lg-6 col-xl-5">
        <div class="card shadow-2-strong" style="border-radius: 1rem;">
          <div class="card-body p-5 text-center">

<div class="right-side">
        <div class="d-grid gap-2 d-md-flex justify-content-md-end">
<button class="btn btn-outline-secondary "><a href="index.php" class="dropdown-item"><i class="bi bi-door-open"></i><i class="bi bi-android"></i> < Back</a></button><br><br>
</div>

<?php

@$id = $_POST['id'];
@$pass = $_POST['pass'];

if (isset($_POST['signin'])) {
	if ($id=="admin" && $pass =="123") {
         
		
     setcookie("cid",$id,time()+30*30);
     



		header("location:classread.php");
		// code...
	}else{

		 

		echo " wrong id and pass!",
		"try again later!";
	}
	// code...
}
?>
            <h3 class="mb-5"> Headofficer Class Sign in</h3>

            <div data-mdb-input-init class="form-outline mb-4">
              <input type="text" id="typeEmailX-2" name="id" class="form-control form-control-lg" />
              <label class="form-label" for="typeEmailX-2">Name</label>
            </div>

            <div data-mdb-input-init class="form-outline mb-4">
              <input type="password" id="typePasswordX-2" name="pass" class="form-control form-control-lg" />
              <label class="form-label" for="typePasswordX-2">Password</label>
            </div>

            <!-- Checkbox -->
            

            <button data-mdb-button-init data-mdb-ripple-init class="btn btn-primary btn-lg btn-block" type="submit" name="signin">Login</button>

            
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
</form>
</div>
<script type="text/javascript">
	var container = document.getElementById("container");
var telaInteira = window.innerWidth;

function logzin() {
	telaInteira = window.innerWidth;
}

setInterval(logzin, 1000);

function createLeaf() {
	var leaf = document.createElement("div");
	leaf.innerHTML =
		'<img src="https://art.pixilart.com/sr20867d214926b.png">';

	leaf.classList.add("leaf");
	leaf.style.left = Math.random() * telaInteira + "px";
	container.appendChild(leaf);
}

setInterval(createLeaf, 100);

var windStrength = 1;

var windDirection = 1;

function updateLeafPosition(leaf) {
	leaf.style.top =
		parseInt(leaf.style.top) + windDirection * windStrength + "px";
	leaf.style.left =
		parseInt(leaf.style.left) + windDirection * windStrength + "px";

	if (parseInt(leaf.style.top) > window.innerHeight) {
		leaf.remove();
	}
}

setInterval(function () {
	var leaves = document.querySelectorAll(".leaf");
	for (var i = 0; i < leaves.length; i++) {
		updateLeafPosition(leaves[i]);
	}
}, 10);

document.addEventListener("mousemove", (event) => {
	var metadeTela = window.innerWidth / 2;
	var xdomouse = event.pageX;
	if (xdomouse > metadeTela) {
		windDirection = 1;
	} else {
		windDirection = -1;
	}
});

document.addEventListener("mousemove", (event2) => {
	var metadeTela = window.innerWidth / 2;
	var xdomouse2 = event2.pageX;
	if (xdomouse2 > metadeTela && xdomouse2 < metadeTela + 300) {
		windStrength = 1;
	} else if (xdomouse2 > metadeTela + 300 && xdomouse2 < metadeTela + 600) {
		windStrength = 2;
	} else if (xdomouse2 > metadeTela + 600) {
		windStrength = 3;
	} else if (xdomouse2 < metadeTela && xdomouse2 > metadeTela - 300) {
		windStrength = 1;
	} else if (xdomouse2 < metadeTela - 300 && xdomouse2 > metadeTela - 600) {
		windStrength = 2;
	} else if (xdomouse2 < metadeTela - 600) {
		windStrength = 3;
	}
});

</script>
</body>
</html>


