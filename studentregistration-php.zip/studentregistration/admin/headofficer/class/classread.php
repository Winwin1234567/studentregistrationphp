<head>
	
	<link rel="stylesheet" type="text/css" href="">



	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>



<script type="text/javascript" src="https://cdn.datatables.net/2.0.8/js/dataTables.js"></script>

<script type="text/javascript" src="https://cdn.datatables.net/2.0.8/js/dataTables.bootstrap4.js"></script>
<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.2/css/bootstrap.css">
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/2.0.8/css/dataTables.bootstrap4.css">

</head>
<style type="text/css">
	

</style>
<body class="bg-danger">
	<center>
	<br>
	<h1 style="color: white;">Class Information</h1>
	<a href="createclass.php" role="button" class="btn btn-outline-secondary">Class Creation</a>
	<a href="#" role="button" class="btn btn-outline-warning">Display</a>
	<a href="logout.php" class="btn btn-outline-info">logout here!</a>

	<div class="table-responsive-sm">
<table  id="example" class="table table-hover table-sm">
	<thead class="table-borderless">

	<tr>
		     <td>ID</td>
			
			<td>Class name</td>
			<td>Timetable</td>
			<td>Starting date</td>
			<td>Accepting student</td>
			<td>Class image</td>

			
			<td>Course summary</td>
			<td>Delete class</td>
			<td>Update class</td>

			
		
	</tr>
	</thead>
	<tbody class="table table-bordered  table-sm ">
	<?php
	error_reporting(1);
	include('connection.php');
	include('redirect.php');
	$q = "SELECT * FROM classlist";
	$val = $con->query($q);
	while (list($classid,$classname,$timetable,$startingdate,$acceptingstudent,$classimg,$coursesummary) = mysqli_fetch_array($val)) {

		echo"<tr>";
		echo "<td >".$classid."</td>";
		echo "<td >".$classname."</td>";
			echo "<td >".$timetable."</td>";
				echo "<td >".$startingdate."</td>";
				if ($acceptingstudent>=2 && $acceptingstudent <= 10) {
					// code...
					echo "<td ><font color='green'>".$acceptingstudent." (Still available!.)</font></td>";
				}elseif ($acceptingstudent == 1) {
					// code...
					echo "<td ><font color='orange'>".$acceptingstudent." (only 1 person is availabe hurry up!!!)</font></td>";
				}else{

					echo "<td ><font color='red'>".$acceptingstudent." (not available right now!please wait another class opening!)</font></td>";
				}
					
						echo "<td><img src='../class/classimage/$classname/$classimg' height='100' width='100'class='rounded'/></td>";

							echo "<td><textarea class='form-control' readonly>".$coursesummary."</textarea></td>";
							echo "<td><center><a onclick='return confirm(\"Are you sure?\")' href='deleteclass.php?cid=$classid&cname=$classname&cimg=$classimg' class='btn btn-danger text-center'>DELETE</a></center></td>";
							echo "<td><center><a href='updateclass.php?classid=$classid' class='btn btn-primary text-center'>UPDATE</a></center></td>";
							//echo "<td><a href='rollcall.php?id=$id' role='button'>Daily Roll Call</a></td>";
							//echo "<td><a href='report.php?id=$studentid' role='button'>Report</a></td>";
							

							echo"</tr>";
				}
		# code...
	

	?>




</table>
</div>

</center>
<script type="text/javascript">
	


	$(document).ready(function() {
    $('#example').DataTable();
} );

</script>
</body>

