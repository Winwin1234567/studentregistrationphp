<head>
	
	<link rel="stylesheet" type="text/css" href="">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>

	<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.min.js" integrity="sha384-0pUGZvbkm6XF6gxjEnlmuGrJXVbNuzT9qBBavbLwCsOGabYfZo0T0to5eqruptLy" crossorigin="anonymous"></script>
</head>
<body>
	<center>
	<br>
	<h1>Class Creation</h1>
	<a href="#" role="button" class="btn btn-outline-secondary">Create Class</a>
	<a href="classread.php" role="button" class="btn btn-outline-warning">Class Display </a>
	<a href="logout.php" class="btn btn-outline-info">logout here!</a>
</center>
<center>
<?php
error_reporting(1);

include('connection.php');
include('redirect.php');
extract($_POST);

if($sub) {

	$q = $con->query("select classname from classlist where classname='$cn'");

	$r = mysqli_num_rows($q);

	if ($r) {
		// code...
		echo "<font color='red'>Class name is already existed! </font>";
	}else{




  $rawdate = htmlentities($_POST['csd']);
$date = date('Y-m-d', strtotime($rawdate));

$cimg=$_FILES['cimg']['name'];







	 $query="insert into classlist values ('','$cn','$ctt','$date','$asn','$cimg','$cs')";
    $con->query($query);

     mkdir("../class/classimage/$cn");
    move_uploaded_file($_FILES['cimg']['tmp_name'],"../class/classimage/$cn/".$_FILES['cimg']['name']);
    

    echo "<font color='blue' align='center'>Congrates Class Insertion Complete!</font>";
    
}

	# code...
}

?>
</center>
<div class="row">
  	<div class="col-sm-4">
  		
  	</div>


<div class="col-sm-4 mt-3">
	<div class="container border" style="max-width: 700px;background-color:lightskyblue;">


<form method="post" enctype="multipart/form-data">

Enter Class Name<input type="text " class="form-control" name="cn" required/><br>
Enter timetable<input type="date "class="form-control" name="ctt" required/><br>
Enter Starting Date 


<input type="date" 
        placeholder="yyyy-mm-dd" value=""
        min="1970-01-01" max="2030-12-31" class="form-control" id="date" placeholder="date" name="csd" required/>  

        <br>
Enter accepting student number <input type="number "class="form-control" name="asn" value="10" readonly /><br>

Choose Class Image<input type="file" class="form-control-file" name="cimg" required/><br>
Course Summary<textarea name="cs" class="form-control" required></textarea><br>

<input type="submit" name="sub" value="INSERT NEW CLASS" class="btn btn-primary" />
</form>
</div>
  </div>
 <div class="col-sm-4">
</div>

</div>
</body>