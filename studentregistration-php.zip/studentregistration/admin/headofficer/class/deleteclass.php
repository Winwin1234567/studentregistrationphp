<?php
include('connection.php');
include('redirect.php');
$q = "DELETE FROM classlist WHERE classid='{$_GET['cid']}'";
$con->query($q);
unlink("../class/classimage/".$_GET['cname']."/".$_GET['cimg']);
rmdir("../class/classimage/".$_GET['cname']);
header('location:classread.php');
?>