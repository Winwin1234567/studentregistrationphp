<head>
	
	<link rel="stylesheet" type="text/css" href="">

	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>



<script type="text/javascript" src="https://cdn.datatables.net/2.0.8/js/dataTables.js"></script>

<script type="text/javascript" src="https://cdn.datatables.net/2.0.8/js/dataTables.bootstrap4.js"></script>
<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.2/css/bootstrap.css">
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/2.0.8/css/dataTables.bootstrap4.css">

</head>
<style type="text/css">
	

</style>
<body class="bg-warning">
	<center>
	<br>
	<h1 style="color: white;">Students Information</h1>
	<a href="index.php" role="button" class="btn btn-outline-secondary"> < Back</a>
	<a href="display.php" role="button" class="btn btn-outline-danger">< Display </a>

<a href="logout.php" class="btn btn-outline-primary">logout here!</a>
<div class="table-responsive-sm">
<table  id="example" class="table table-hover table-sm">
	<thead class="table-borderless">


	<tr>
		     <td>ID</td>
			<td>Student ID</td>
			<td>Student name</td>
			<td>Student Date of birth</td>
			
			<td>mobile</td>
			<td>City</td>
			
			<td>Student photos</td>
			<td>Report percentage</td>
			<td>Warning!</td>
			
		
	</tr>
	</thead>
	<tbody class="table table-bordered  table-sm ">
	<?php
	error_reporting(1);
	include('connection.php');
	include('redirect.php');
	$sid = $_GET['id'];

$val = $con->query("SELECT * FROM studentlist WHERE studentid='$sid'");
$data = mysqli_fetch_array($val);



 $val1 = $con->query("SELECT COUNT(DISTINCT studentid) as total
FROM studentlist");
 $data1 = mysqli_fetch_array($val1);



	

	$percent = "SELECT ROUND((SELECT COUNT(*) FROM studentlist WHERE status = 'present' AND studentid ='$sid') * 100 / COUNT(*))  AS percentage FROM studentlist WHERE studentid = '$sid'";
	$percentval = $con->query($percent);
	$percentdata = mysqli_fetch_array($percentval);

    

	

		echo"<tr>";
		echo "<td >".$data['id']."</td>";
		echo "<td >".$data['studentid']."</td>";
			echo "<td >".$data['studentname']."</td>";
				echo "<td >".$data['studentdob']."</td>";
				
					
						echo "<td>".$data['mobile']."</td>";
						echo "<td>".$data['city']."</td>";
							
							echo "<td><img src='../../user/image/".$data['studentid']."/".$data['img']."' height='100' width='100'/></td>";
                               if ($percentdata['percentage'] >= 75) {

                               	echo "<td><font color='green'>".$percentdata['percentage']."%</font></td>";
                               	// code...
                               }elseif ($percentdata['percentage'] >= 50 && $percentdata['percentage'] <=75) {

                               	// code...
                               		echo "<td><font color='orange'>".$percentdata['percentage']."%</font></td>";
                               }else{

                               	echo "<td ><font color='red'>".$percentdata['percentage']."% .invalid to take test.</font></td>";
                               }
							

                           
							if($percentdata['percentage']   >= 75) {
					// code...
					echo "<td ><font color='green'>Excellent!Great job!</font></td>";
				}elseif ($percentdata['percentage'] >= 50 && $percentdata['percentage'] <= 75) {
					// code...
					echo "<td ><font color='orange'>Please attend class regularly!".$percentdata['percentage']."%</font></td>";
				}else{

					echo "<td ><font color='red'>Please call your Mommy.".$percentdata['percentage']."%</font></td>";
				}
						
							
							

							echo"</tr>";
				
		# code...
	
     
	?>


</table>
</div>

</center>
<script type="text/javascript">
	


	$(document).ready(function() {
    $('#example').DataTable();
} );

</script>
</body>


