<!DOCTYPE html>
<html>
<head>
	
</head>
<style type="text/css">
 @import url('https://fonts.googleapis.com/css?family=Raleway:400,700');

body {
  background: #c0c0c0; 
  font-family: Raleway, sans-serif;
  color: #666;
}

.login {
  margin: 20px auto;
  padding: 40px 50px;
  max-width: 300px;
  border-radius: 5px;
  background: #fff;
  box-shadow: 1px 1px 1px #666;
}
  .login input {
    width: 100%;
    display: block;
    box-sizing: border-box;
    margin: 10px 0;
    padding: 14px 12px;
    font-size: 16px;
    border-radius: 2px; 
    font-family: Raleway, sans-serif;
  }

.login input[type=text],
.login input[type=password] {
  border: 1px solid #c0c0c0;
  transition: .2s;
}

.login input[type=text]:hover {
  border-color: #F44336;
  outline: none;
  transition: all .2s ease-in-out;
} 

.login .dropdown-item{
  border: none;
  background: #EF5350;
  color: white;
  font-weight: bold;  
  transition: 0.2s;
  margin: 20px 0px;
}

.login .dropdown-item:hover {
  background: #F44336;  
}

  .login h2 {
    margin: 20px 0 0; 
    color: #EF5350;
    font-size: 28px;
  }

.login p {
  margin-bottom: 40px;
}

.links {
  display: table;
  width: 100%;  
  box-sizing: border-box;
  border-top: 1px solid #c0c0c0;
  margin-bottom: 10px;
}

.links a {
  display: table-cell;
  padding-top: 10px;
}

.links a:first-child {
  text-align: left;
}

.links a:last-child {
  text-align: right;
}

  .login h2,
  .login p,
  .login a {
    text-align: center;    
  }

.login a {
  text-decoration: none;  
  font-size: .8em;
}

.login a:visited {
  color: inherit;
}

.login a:hover {
  text-decoration: underline;
}
</style>

<body>
    <?php 
    include('booststyleconnect/styleconnection.php');
    ?>
        <div class="container-xxl bg-white p-0">
        <!-- Spinner Start -->
        <div id="spinner" class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
            <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status">
                <span class="sr-only">Loading...</span>
            </div>
        </div>
        <!-- Spinner End -->


        <!-- Navbar Start -->
        <nav class="navbar navbar-expand-lg bg-white navbar-light sticky-top px-4 px-lg-5 py-lg-0">
            <a href="index.html" class="navbar-brand">
                <h1 class="m-0 text-secondary"><i class="fa-sharp fa-solid fa fa-school me-3"></i>AI School</h1>
            </a>
            <button type="button" class="navbar-toggler" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarCollapse">
                <div class="navbar-nav mx-auto">
                    <a href="../../index.php" class="nav-item nav-link text-secondary">Home</a>
                    <a href="../../ourteacher.php" class="nav-item nav-link text-secondary">Our Great Teachers</a>
                    <a href="../../outstandingstudentboostrap.php" class="nav-item nav-link text-secondary">Our Outstanding Students</a>
                    <a href="../../user/index.php" class="nav-item nav-link text-secondary">Register Students!</a>
                    <div class="nav-item dropdown">
                        <a href="#" class="nav-link dropdown-toggle text-primary" data-bs-toggle="dropdown">Authority</a>
                        <div class="dropdown-menu rounded-0 rounded-bottom border-0 shadow-sm m-0">
                            <a href="../index.php" class="dropdown-item text-secondary">Admin</a>
                             <a href="index.php" class="dropdown-item text-primary">Boss</a>
                            <a href="student/index.php" class="dropdown-item">Manage Student</a>
                            <a href="luckydraw/index.php" class="dropdown-item">Manage Scholarship</a>
                            
                        </div>
                    </div>
                    <a href="#" class="nav-item nav-link">Contact Us</a>
                </div>
                <a href="#" class="btn btn-primary rounded-pill px-3 d-none d-lg-block">Join Us<i class="fa fa-arrow-right ms-3"></i></a>
            </div>
        </nav>
        <!-- Navbar End -->
</div>




<form class="login">
  <h2>Welcome, Boss!</h2>
  <p>Please log in</p>
  
  <button class="dropdown-item"><center><a href="login.php">login here!</a></center></button>
  
  
</form>

<?php include('footer.php') ?>
       
</body>
</html>