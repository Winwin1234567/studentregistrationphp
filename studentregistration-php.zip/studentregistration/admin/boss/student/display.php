<head>
		<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>



<script type="text/javascript" src="https://cdn.datatables.net/2.0.8/js/dataTables.js"></script>

<script type="text/javascript" src="https://cdn.datatables.net/2.0.8/js/dataTables.bootstrap4.js"></script>
<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.2/css/bootstrap.css">
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/2.0.8/css/dataTables.bootstrap4.css">




</head>
<style type="text/css">
	

</style>
<body class="bg-info">
	<center>
	<br>
	<h1 style="color: white;">Students Information</h1>
	<a href="index.php" role="button" class="btn btn-outline-secondary">Back < < </a>
	<a href="#" role="button" class="btn btn-outline-warning">Display</a>

	<a href="logout.php" class="btn btn-outline-light">logout here!</a>
	<div class="table-responsive-sm">
<table  id="example" class="table table-hover table-sm">
	<thead class="table-borderless">
	<tr>
		     <th>ID</th>
			<th>StudentID</th>
			<th>Studentname</th>
			<th>StudentDate of birth</th>
			<th>Attendance status</th>
			<th>mobile</th>
			<th>City</th>
			
			<th> photos</th>
			<th>Attendance date</th>
			<th>Class data</th>
			<th>delete</th>
			<th>multipleedit</th>
			<th>singleedit</th>
			<th>Dailyrollcall </th>
			<th>report</th>
			<th>completion status</th>
		
	</tr>
</thead>
<tbody class="table table-bordered  table-sm ">
	<?php
	error_reporting(1);
	
	include('connection.php');
	include('redirect.php');
	$q = "SELECT * FROM studentlist";
	$val = $con->query($q);
	while (list($id,$studentid,$studentname,$studentdob,$status,$mobile,$city,$img,$attendance_date,$classidid,$classnamename,$completestatus) = mysqli_fetch_array($val)) {

		echo"<tr>";
		echo "<td >".$id."</td>";
		//echo "<td >".$studentid."</td>";


                           if ($completestatus == "new") {
					// code...
					echo "<td ><font color='red'>".$studentid."</font></td>";
				}elseif ($completestatus == "no") {
					// code...
					echo "<td ><font color='green'>".$studentid."</font></td>";
				}elseif($completestatus=="yes"){

					echo "<td ><font color='gold'>".$studentid."</font></td>";
				}
			echo "<td >".$studentname."</td>";
				echo "<td >".$studentdob."</td>";
				if ($status == "present") {
					// code...
					echo "<td ><font color='green'>".$status."</font></td>";
				}elseif ($status == "absent") {
					// code...
					echo "<td ><font color='red'>".$status."</font></td>";
				}else{

					echo "<td ><font color='white'>".$status."</font></td>";
				}
					
						echo "<td>".$mobile."</td>";
						echo "<td>".$city."</td>";
							
							echo "<td><img src='../../../user/image/$studentid/$img' height='100' width='100' class='rounded-circle'/></td>";

							echo "<td>".$attendance_date."</td>";
							//echo "<td><a href='delete.php?id=$id&sid=$studentid&img=$img' role='button'>DELETE</a></td>";
                             echo "<td>".$classidid." ".$classnamename."</td>";

							echo "<td><a onclick='return confirm(\"Are you sure?\")' href='delete.php?id=$id&sid=$studentid&img=$img'  class='btn btn-danger'>DELETE</a></td>";
							echo "<td><a href='edit.php?id=$studentid' class='btn btn-primary'>multipleEdit</a></td>";
							echo "<td><a href='singleedit.php?id=$id' class='btn btn-secondary'>SingleEdit</a></td>";
							echo "<td><a href='rollcall.php?id=$id' class='btn btn-info'>Daily Roll Call</a></td>";
							echo "<td><a href='report.php?id=$studentid' class='btn btn-danger'>Report</a></td>";
							
                           echo "<td >".$completestatus."</td>";

							echo"</tr>";
				}
		# code...
	

	?>
</tbody>
</table>
</div>

</center>
<script type="text/javascript">
	


	$(document).ready(function() {
    $('#example').DataTable();
} );

</script>

</body>

