<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">


	<title></title>

	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>

	<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.min.js" integrity="sha384-0pUGZvbkm6XF6gxjEnlmuGrJXVbNuzT9qBBavbLwCsOGabYfZo0T0to5eqruptLy" crossorigin="anonymous"></script>
</head>
<body>
<?php 


@$id = $_POST['id'];
if (isset($_POST['sub'])) {
	if ($id=="logout") {
         
		
     setcookie("cid",$id,time()-30*30);
     



		header("location:index.php");
		// code...
	}else{

		 

		echo " wrong id ",
		"try again later!";
	}
}
?>


<div class="row">
	<div class="col-sm-4"></div>
	<div class="col-sm-4">
<div class="card mt-3">
  <h5 class="card-header">Hello!</h5>
  <div class="card-body">
    <h5 class="card-title">Welcome Back!</h5>
    
<p class="card-text">Are you sure want to logout!boss!</p>
    <form method="post">
	
	<input type="hidden" name="id" value="logout" /><br><br>
	<!--Enter password <input type="password" name="pass" />-->
	<button class="btn btn-primary"><input type="submit" name="sub" value="OK" role="button"  class="btn btn-primary "></button>
</form>
    </div>
  </div>
</div>
<div class="col-sm-4"></div>
</div>
</body>
</html>