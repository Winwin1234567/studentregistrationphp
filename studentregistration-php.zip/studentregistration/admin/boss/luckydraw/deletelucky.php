<?php
include('connection.php');
include('redirect.php');
$q = "DELETE FROM prize WHERE prizeid='{$_GET['luckyid']}'";
$con->query($q);

header('location:luckyread.php');
?>