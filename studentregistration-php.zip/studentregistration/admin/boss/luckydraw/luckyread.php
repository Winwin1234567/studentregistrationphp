<head>
	
	<link rel="stylesheet" type="text/css" href="">

	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>



<script type="text/javascript" src="https://cdn.datatables.net/2.0.8/js/dataTables.js"></script>

<script type="text/javascript" src="https://cdn.datatables.net/2.0.8/js/dataTables.bootstrap4.js"></script>
<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.2/css/bootstrap.css">
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/2.0.8/css/dataTables.bootstrap4.css">

</head>
<style type="text/css">
	

</style>
<body class="bg-secondary">
	<center>
	<br>
	<h1 style="color: white;">luckydraw Information</h1>
	<a href="index.php" role="button" class="btn btn-outline-light">Back < </a>
	<a href="#" role="button" class="btn btn-outline-warning">luckydraw Display</a>
	<a href="logout.php" class="btn btn-outline-primary">logout here!</a>

	<div class="table-responsive-sm">
		<table  id="example" class="table table-hover table-sm">
<thead class="table-borderless">
	<tr>
		     <td>ID</td>
			
			<td>Prize Name</td>
			<td>Student ID</td>
			<td>Student Name</td>
			<td>Sir Remark</td>
			<td>Sir Remark Date</td>
			<td>Boss scholarship</td>
			
			<td>Delete</td>
			<td>Update</td>

			

		

			
		
	</tr>
	</thead>
<tbody class="table table-bordered  table-sm ">
	<?php
	error_reporting(1);
	include('connection.php');
	include('redirect.php');
	$q = "SELECT * FROM prize";
	$val = $con->query($q);
	while (list($prizeid,$prizename,$studentid,$studentname,$remark,$remarkdate,$img,$bossreward,$classname) = mysqli_fetch_array($val)) {

		echo"<tr>";
		echo "<td >".$prizeid."</td>";
		echo "<td >".$prizename."</td>";
			echo "<td >".$studentid."</td>";
				echo "<td >".$studentname."</td>";
				echo "<td >".$remark."</td>";
				echo "<td >".$remarkdate."</td>";
				echo "<td >".$bossreward."</td>";
				
							echo "<td><a onclick='return confirm(\"Are you sure?\")' href='deletelucky.php?luckyid=$prizeid&luckyname=$prizename' class='bt btn-danger'>DELETE</a></td>";
							echo "<td><a href='updatelucky.php?luckyid=$prizeid' class='btn btn-warning'>UPDATE</a></td>";
							//echo "<td><a href='rollcall.php?id=$id' role='button'>Daily Roll Call</a></td>";
							//echo "<td><a href='report.php?id=$studentid' role='button'>Report</a></td>";
							

							echo"</tr>";
				}
		# code...
	

	?>


</tbody>
</table>
</div>
</center>
<script type="text/javascript">
	


	$(document).ready(function() {
    $('#example').DataTable();
} );

</script>


</body>

