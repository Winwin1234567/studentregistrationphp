<?php
if (!isset($_COOKIE['cid'])) {
    echo "timeout login again";
	header("location:index.php");

	exit();
	// code...
}


?>

