
<head>
	
	<link rel="stylesheet" type="text/css" href="">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>

	<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.min.js" integrity="sha384-0pUGZvbkm6XF6gxjEnlmuGrJXVbNuzT9qBBavbLwCsOGabYfZo0T0to5eqruptLy" crossorigin="anonymous"></script>
</head>

<style type="text/css">
	
</style>
<body>
	<center>
	<br>
	<h1>Scholarship Update Form!</h1>
	<a href="luckyread.php" role="button" class="btn btn-outline-secondary">Back</a>
	<a href="#" role="button" class="btn btn-outline-warning">Display</a>
	<a href="logout.php" class="btn btn-outline-info">logout here!</a>
</center>
<?php
error_reporting(1);
include('connection.php');
include('redirect.php');




$luckyid = $_GET['luckyid'];
$val = $con->query("SELECT * FROM prize WHERE prizeid=$luckyid");
$data = mysqli_fetch_array($val);

extract($_POST);
if (isset($sub)) {

	$rawdate = htmlentities($_POST['rd']);
$rdate = date('Y-m-d', strtotime($rawdate));



	$con->query("update prize set prizeid='$pid',prizename='$pn',studentid='$sid',studentname='$sn',remark='$dr',remarkdate='$rdate',bossreward='$bs' where prizeid=$luckyid");
	header('location:luckyread.php');
	# code...
}


	# code...


?>
<div class="row">
  	<div class="col-sm-4">
  		
  	</div>


<div class="col-sm-4 mt-3">
	<div class="container border" style="max-width: 700px;background-color:lightskyblue;">


<form method="post" enctype="multipart/form-data">




 Prize ID<input type="text" class="form-control" name="pid"  value="<?php echo $data['prizeid'];?>" readonly /><br>
Enter Prize Name<input type="text " class="form-control" name="pn" value="<?php echo $data['prizename'];?>"required/><br>
Enter Student ID<input type="text " class="form-control" name="sid" value="<?php echo $data['studentid'];?>" readonly/><br>
 Student Name <input type="text " class="form-control" name="sn" value="<?php echo $data['studentname'];?>" readonly /><br>
Remark Summary <textarea class="form-control" name="dr" ><?php echo $data['remark']; ?></textarea><br>
Enter Remark Date 


<input type="date" 
        placeholder="yyyy-mm-dd" 
        min="1970-01-01" max="2030-12-31" class="form-control" id="date"  name="rd" value="<?php echo $data['remarkdate']?>"  required/><br>  

Enter Boss reward <input type="text " class="form-control" name="bs" value="<?php echo $data['bossreward'];?>" required/><br>


Enter Class name<input type="text " class="form-control" name="cn" value="<?php echo $data['classname'];?>" readonly/><br>

<input type="submit" name="sub" value="INSERT Update" role='button' class="btn btn-primary" />
</form>
</div>
  </div>
 <div class="col-sm-4">
</div>

</div>

</body>