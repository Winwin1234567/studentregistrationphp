<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>


<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>



<script type="text/javascript" src="https://cdn.datatables.net/2.0.8/js/dataTables.js"></script>

<script type="text/javascript" src="https://cdn.datatables.net/2.0.8/js/dataTables.bootstrap4.js"></script>
<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.2/css/bootstrap.css">
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/2.0.8/css/dataTables.bootstrap4.css">

	
	<link rel="stylesheet" type="text/css" href="">
</head>
<style type="text/css">
	

</style>
<body class="bg-warning">
	<center>
	<br>
	<h1 style="color: white;">Students Information(Daily roll call!)</h1>
	<a href="index.php" role="button" class="btn btn-outline-secondary"> << Back</a>
	<a href="#" role="button" class="btn btn-outline-primary">Display</a>

<a href="logout.php" class="btn btn-outline-info">log out!</a>

<div class="table-responsive-sm">
<table  id="example" class="table table-hover table-sm">
	<thead class="table-borderless text-white">


	<tr>

		     <td>ID</td>
			<td>Student ID</td>
			<td>Student name</td>
			<td>Student Date of birth</td>
			<td>Attendance status</td>
			<td>mobile</td>
			
			
			
			<td>Attendance date</td>
			<td>Class Data</td>
			
			<td>singleedit</td>
			<td>roll call (add new row to gain report)</td>
			<td>report</td>
			
		
	
	</tr>

	</thead>
<tbody class="table table-bordered  table-sm ">
	<?php
	error_reporting(1);
	include('connection.php');
	include('redirect.php');
	$q = "SELECT * FROM studentlist";
	$val = $con->query($q);
	while (list($id,$studentid,$studentname,$studentdob,$status,$mobile,$city,$img,$attendance_date,$classidid,$classnamename,$completestatus) = mysqli_fetch_array($val)) {

		echo"<tr>";
		echo "<td >".$id."</td>";
		echo "<td >".$studentid."</td>";
			echo "<td >".$studentname."</td>";
				echo "<td >".$studentdob."</td>";
				if ($status == "present") {
					// code...
					echo "<td ><font color='green'>".$status."</font></td>";
				}elseif ($status == "absent") {
					// code...
					echo "<td ><font color='red'>".$status."</font></td>";
				}else{

					echo "<td ><font color='white'>".$status."</font></td>";
				}
					
						echo "<td>".$mobile."</td>";
					
							
						

							echo "<td>".$attendance_date."</td>";
							echo "<td>".$classidid." ".$classnamename."</td>";
							
							echo "<td><a href='singleedit.php?id=$id' role='button' class='btn btn-outline-primary'>SingleEdit</a></td>";
							
							echo "<td><a href='rollcall.php?id=$id'  role='button' class='btn btn-outline-secondary'>Daily Roll Call</a></td>";
							echo "<td><a href='report.php?id=$studentid&classid=$classidid' role='button' class='btn btn-outline-warning'>Report</a></td>";
							
                          
							echo"</tr>";
				}
		# code...
	

	?>


</tbody>
</table>
</div>

</center>
<script type="text/javascript">
	


	$(document).ready(function() {
    $('#example').DataTable();
} );

</script>