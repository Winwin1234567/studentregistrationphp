<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
</head>
<body>
<?php 


@$id = $_POST['id'];
if (isset($_POST['sub'])) {
	if ($id=="logout") {
         
		
     setcookie("cid",$id,time()-30*30);
     



		header("location:userclassread.php");
		// code...
	}else{

		 

		echo " wrong id ",
		"try again later!";
	}
}
?>
<form method="post">
	
	<input type="hidden" name="id" value="logout" /><br><br>
	<!--Enter password <input type="password" name="pass" />-->
	<input type="submit" name="sub" value="log out">
</form>
</body>
</html>