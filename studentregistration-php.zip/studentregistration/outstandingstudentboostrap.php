<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
	 <link rel="stylesheet" type="text/css" href="css/anistyle2.css">
</head>
<style type="text/css">
	p.a{
		font-family: "Times New Roman", Times, serif;
		  font-size: 14px;
	}
	 .card:hover{
		transform: scale(1.5,1.5);
	}
	 .card{
		transition: all 0.3s;
	}
	

</style>
<body class="bg-dark">














<?php
include('booststyleconnect/styleconnection.php');

include('userheader2.php');
?>




	
	
<br><br><br>
	<div class="container ">
       <div class="row">


	<?php
	include("connection.php");
	

$q = "SELECT * FROM prize WHERE bossreward >=100000";
	$val = $con->query($q);
	
	while (list($prizeid,$prizename,$studentid,$studentname,$remark,$remarkdate,$img,$bossreward,$classname) = mysqli_fetch_array($val)) {



        if ($bossreward >= 500000) {
		echo"<div class='col-sm-4' >
		<div class='card bg-warning'style='max-width: 300px;'>

		<center><img src='./user/image/$studentid/$img'  style='width:50%;' height='150px' class='rounded-circle card-img-top flicker-1' alt=''/></center>
		<div class='card-content text-center'>
		
			<h4><i class='bi bi-cash-stack'>Discount-$prizename-mmk</i><h4>

		<p class='a'>ID- $studentid</p>
		<p class='a'><i class='bi bi-person-circle'> $studentname</i></p>
	    <p class='a'><i class='bi bi-trophy'> $remark</i></p>
	    <p class='a '>
<span class='fa fa-star flicker-1'  style='color:green'></span>
<span class='fa fa-star flicker-1' style='color:green'></span>
<span class='fa fa-star flicker-1'style='color:green'></span>
<span class='fa fa-star flicker-1'style='color:green'></span>
<span class='fa fa-star flicker-1'style='color:green'></span>

	boss Scholarship-$bossreward-mmk</p>
		<p class='a'>$remarkdate</p>

		</div>
		</div>
		<br><br>
		</div>";
		

		}elseif ($bossreward > 200000 && $bossreward < 500000) {
         
			echo"<div class='col-sm-4' >
		<div class='card bg-info' style='max-width: 300px;'>
		<center><img src='./user/image/$studentid/$img' style='width:50%;' height='150px' class='rounded-circle card-img-top flicker-1' alt=''/></center>
		<div class='card-content  text-center'>
		
			<h4><i class='bi bi-cash-stack'>Discount-$prizename-mmk</i><h4>
		<p class='a'>ID-$studentid</p>
		<p class='a'><i class='bi bi-person-circle'> $studentname</i></p>
	    <p class='a'><i class='bi bi-trophy'> $remark</i></p>
	    <p class='a'>
<span class='fa fa-star flicker-1'style='color:silver'></span>
<span class='fa fa-star flicker-1'style='color:silver'></span>
<span class='fa fa-star flicker-1'style='color:silver'></span>
<span class='fa fa-star flicker-1'style='color:silver'></span>
	    Boss Scholarship-$bossreward-mmk</p>
		<p class='a'>$remarkdate</p>
		</div>
		</div>
		<br><br>
		</div>";
	}elseif($bossreward <=200000){
      
		echo"<div class='col-sm-4' >
		<div class='card bg-secondary' style='max-width: 300px;'>
		<center><img src='./user/image/$studentid/$img' style='width:50%;' height='150px' class='rounded-circle card-img-top flicker-1' alt=''/></center>
		<div class='card-content  text-center'>
		
			<h4><i class='bi bi-cash-stack'>Discount-$prizename-mmk</i><h4>
		<p class='a'>ID-$studentid</p>
		<p class='a'><i class='bi bi-person-circle'> $studentname</i></p>
	    <p class='a'><i class='bi bi-trophy'> $remark</i></p>
	    <p class='a'>
	    <span class='fa fa-star flicker-1'style='color:blue'></span>
<span class='fa fa-star flicker-1'style='color:blue'></span>
<span class='fa fa-star flicker-1'style='color:blue'></span>

	    Boss Scholarship-$bossreward-mmk</p>
		<p class='a'>$remarkdate</p>
		</div>
		</div>
		<br><br>
		</div>";

			// code...
		}else{
    echo "<h1 colspan='8' class='text-center'>
   <b> There is no outstanding students!</b></h1>";
}		
				
				
}					// code...
				


	?>



 <?php include('footer.php') ?>


</div>
</div>


	

</body>
</html>


				
	
